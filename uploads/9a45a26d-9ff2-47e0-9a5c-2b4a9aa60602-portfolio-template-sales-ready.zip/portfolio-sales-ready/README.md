# Portfolio Template - Ready for Sale

A modern, responsive portfolio template perfect for developers and designers. This template features a sleek design with smooth animations, multi-language support (Arabic/English), and is fully customizable.

## ✨ Features

- 🎨 **Modern Design** - Clean, professional layout with glassmorphism effects
- 📱 **Fully Responsive** - Works perfectly on desktop, tablet, and mobile
- 🌍 **Multi-language Support** - Built-in Arabic/English language toggle
- ⚡ **Performance Optimized** - Fast loading with smooth animations
- ♿ **Accessibility Ready** - Semantic HTML with proper ARIA labels
- 🔧 **Easy Customization** - Well-organized code with clear comments
- 📧 **Contact Form** - Functional contact form (opens email client)
- 🎯 **Project Showcase** - Beautiful project cards with detailed descriptions

## 🚀 Quick Start

### Option 1: Live Server (Recommended)
```bash
# Install dependencies
npm install

# Start development server
npm run dev
```

### Option 2: Simple HTTP Server
```bash
# Start simple HTTP server
npm start
```

### Option 3: Direct File Opening
Simply open `index.html` in your web browser.

## 📁 File Structure

```
portfolio-template/
├── index.html          # Main portfolio page
├── styles.css          # Complete styling
├── script.js           # Interactions & i18n
├── package.json        # Project configuration
└── README.md          # This file
```

## 🛠️ Customization Guide

### Personal Information
Update the following in `index.html`:
- **Name**: Change "John Doe" to your name (lines 25, 53, 90, 387)
- **Email**: Update "john@example.com" to your email (line 348)
- **Location**: Modify location text (line 352)
- **LinkedIn**: Add your LinkedIn profile link (line 356)

### Projects Section
Update project details in the projects section (lines 254-324):
- Project titles and descriptions
- Technologies used
- Project links and demo URLs

### Skills Section
Modify skills in the skills section (lines 229-240):
- Add/remove skill chips
- Update skill categories

### Colors & Styling
Customize colors in `styles.css` (lines 1-24):
- `--bg`: Background color
- `--text`: Text color
- `--bronze`: Accent color
- `--silver`: Secondary accent color

### Language Content
Update translations in `script.js` (lines 1-212):
- Arabic translations (lines 2-106)
- English translations (lines 107-211)

## 📧 Contact Form Configuration

The contact form is configured to open the user's default email client. To customize:
1. Update the email in `script.js` line 272
2. For backend integration, replace the form submission logic in `initContactForm()`

## 🌐 Multi-language Support

This template includes:
- **Arabic (RTL)** - Default language
- **English (LTR)** - Toggle option
- **Language Toggle** - Button in the navigation
- **Persistent Selection** - Saves user preference

## 📱 Responsive Breakpoints

- **Desktop**: > 980px - Full grid layout
- **Mobile**: ≤ 980px - Single column layout
- **Reduced Motion**: Respects user accessibility preferences

## 🔧 Browser Support

- ✅ Chrome/Chromium 80+
- ✅ Firefox 75+
- ✅ Safari 13+
- ✅ Edge 80+

## 📄 License

This template is licensed under MIT. You can use it for personal and commercial projects.

## 🤝 Support

For questions or customization help, please refer to the code comments or contact the template provider.

---

**Note**: This is a template with dummy content. Replace all placeholder information with your own details before using.
