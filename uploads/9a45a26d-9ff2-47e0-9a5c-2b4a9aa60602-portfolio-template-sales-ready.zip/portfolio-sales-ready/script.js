const i18n = {
  ar: {
    cta: "خلّينا نشتغل سوا",
    badge: "Front-End Developer",
    nav: { about: "عنّي", highlights: "Highlights", skills: "المهارات", projects: "المشاريع", contact: "تواصل" },
    hero: {
      hi: "مرحبًا، أنا",
      subtitle:
        "فرونت إند ديف بخبرة 3 سنين. ببني تجارب ويب سريعة، جذابة، وقابلة للتوسع باستخدام HTML/CSS/JavaScript وReact.",
      viewWork: "شوف شغلي",
      contact: "تواصل معايا",
    },
    kpi: { years: "سنين خبرة", projects: "أهم المشاريع", focus: "تركيز أساسي" },
    highlights: {
      title: "Highlights",
      desc: "نقط قوة بتظهر في الشغل اليومي — من السرعة للتفاصيل.",
      ai: {
        title: "AI-first workflow",
        text: "خبرة رهيبة في استخدام الذكاء الاصطناعي لتسريع التنفيذ: توليد أفكار، تحسين UX copy، ورفع جودة الكود.",
      },
      vibe: {
        title: "Vibe Coding",
        text: "سنة خبرة في الـ Vibe Coding: تحويل الفكرة لواجهة كاملة بسرعة مع الحفاظ على الجودة والتنظيم.",
      },
      ux: {
        title: "Micro-interactions",
        text: "بحط لمسات صغيرة تفرق: transitions ناعمة، states واضحة، وتجربة استخدام “premium”.",
      },
      perf: {
        title: "Performance mindset",
        text: "بشتغل بعقلية الأداء: تقليل re-render، تحسين تحميل الصفحة، وتجربة سريعة خصوصًا على الموبايل.",
      },
      a11y: {
        title: "Accessibility",
        text: "اهتمام بـ Accessibility: keyboard navigation، contrast مضبوط، وتجربة واضحة للجميع.",
      },
      ship: {
        title: "Ship fast, ship clean",
        text: "سرعة في التسليم مع كود نظيف: naming واضح، components قابلة لإعادة الاستخدام، وتنظيم ملفات محترم.",
      },
    },
    about: {
      title: "عنّي",
      desc:
        "بحب التفاصيل الصغيرة اللي بتفرق: انتقالات ناعمة، Typography مظبوطة، وتجربة مستخدم محسوبة — مع كود نظيف وسهل التطوير.",
      whatIDoTitle: "أنا بعمل إيه؟",
      whatIDoText:
        "بشتغل على واجهات ويب حديثة من التصميم لحد تنفيذ UI Components، وبضمن إنها Responsive وسريعة على الموبايل والديسكتوب.",
      specialty: "Specialty",
      exp: "Experience",
      highlightTitle: "نقطة قوة",
      highlightText:
        "أقدر أحوّل أي فكرة لتجربة حقيقية: Layout واضح، Accessibility، واهتمام بالأداء — خصوصًا في المشاريع اللي فيها تفاعل عالي.",
      quote: "Build something people love to use.",
    },
    skills: {
      title: "المهارات",
      desc: "التقنيات اللي بشتغل بيها يوميًا + اللي بستخدمها في المشاريع اللي تحت.",
    },
    projects: {
      title: "أهم المشاريع",
      desc: "3 مشاريع قوية: تجربة تفاعلية (Game)، تطبيق شات ذكي، ومنصة اجتماعية Real-time.",
      openLocal: "فتح محليًا",
      live: "Live",
      github: "GitHub",
      readme: "Readme",
      note: { roleK: "الدور:", challengeK: "التحدي:", outcomeK: "النتيجة:" },
      noteTitle: "ملاحظة",
      noteText: "لو حابب تفاصيل أكتر عن أي مشروع (دورك، التحديات، أو الديمو)، ابعتلي رسالة وهشاركك كل التفاصيل.",
      cityshift: {
        subtitle: "2D driving game بواجهة HUD واقعية + Autodrive + Map overlay.",
        roleV: "تنفيذ اللعبة بالكامل + HUD + المنيوهات والتفاعل.",
        challengeV: "ضبط الفيزيكس والإحساس بالسواقة مع واجهة HUD تشتغل بسلاسة.",
        outcomeV: "تجربة لعب سريعة وتفاعلية مع Map Overlay وAutodrive.",
      },
      chatforge: {
        subtitle: "مولّد شاتات مخصصة + Import/Export + Stats + Favorites + تلخيص بالذكاء الاصطناعي.",
        roleV: "تصميم وبناء UI متعدد الصفحات + إدارة الحالة والتخزين المحلي.",
        challengeV: "تنظيم بيانات المحادثات والبحث والمفضلة بدون Backend مع UX سريع.",
        outcomeV: "تجربة قوية فيها Import/Export وStats وتلخيص وتوليد صور.",
      },
      neuraconnect: {
        subtitle: "Real-time social platform: Stories, Posts, Meetings + WebSocket + AI features.",
        roleV: "تطوير Features حقيقية: Auth، Feed، Stories، وMeetings مع Real-time.",
        challengeV: "تزامن الأحداث في الاجتماعات (WebSocket) مع تجربة UI مستقرة.",
        outcomeV: "منصة فيها Live meetings + AI features وهيكل واضح للتوسع.",
      },
    },
    contact: {
      title: "تواصل",
      desc: "لو عندك فرصة شغل أو مشروع جديد — ابعتلي تفاصيل بسيطة وأنا هرد بسرعة.",
      quick: "Quick contact",
      email: "Email",
      location: "Location",
      locationValue: "Egypt",
      addLinks: "(ضيف رابطك)",
    },
    form: {
      name: "الاسم",
      email: "الإيميل",
      message: "الرسالة",
      send: "إرسال",
      hint: "الفورم دي بتفتح إيميلك تلقائيًا (بدون Backend). لو تحب أضيف إرسال فعلي عبر EmailJS/Server قولّي.",
    },
    footer: { backTop: "رجوع لفوق" },
  },
  en: {
    cta: "Let’s work together",
    badge: "Front-End Developer",
    nav: { about: "About", highlights: "Highlights", skills: "Skills", projects: "Projects", contact: "Contact" },
    hero: {
      hi: "Hi, I’m",
      subtitle:
        "Front-end developer with 3 years of experience. I build fast, modern, scalable web experiences using HTML/CSS/JavaScript and React.",
      viewWork: "View work",
      contact: "Contact me",
    },
    kpi: { years: "Years exp", projects: "Top projects", focus: "Main focus" },
    highlights: {
      title: "Highlights",
      desc: "Strengths that show up in daily work — from speed to details.",
      ai: {
        title: "AI-first workflow",
        text: "Strong experience using AI to accelerate delivery: idea generation, UX copy polish, and code-quality improvements.",
      },
      vibe: {
        title: "Vibe Coding",
        text: "1 year of Vibe Coding: turning ideas into full UI fast while keeping quality and structure.",
      },
      ux: {
        title: "Micro-interactions",
        text: "Small details that matter: smooth transitions, clear states, and a premium feel.",
      },
      perf: {
        title: "Performance mindset",
        text: "Performance-driven approach: fewer re-renders, faster loads, and a great mobile experience.",
      },
      a11y: {
        title: "Accessibility",
        text: "Accessibility-focused: keyboard navigation, solid contrast, and inclusive UX.",
      },
      ship: {
        title: "Ship fast, ship clean",
        text: "Fast delivery with clean code: clear naming, reusable components, and solid structure.",
      },
    },
    about: {
      title: "About",
      desc:
        "I care about the details that matter: smooth transitions, strong typography, and thoughtful UX — backed by clean, maintainable code.",
      whatIDoTitle: "What I do",
      whatIDoText:
        "I build modern web interfaces end-to-end: from layout to reusable UI components — always responsive and performance-minded.",
      specialty: "Specialty",
      exp: "Experience",
      highlightTitle: "Strength",
      highlightText:
        "I turn ideas into polished experiences: clear layout, accessibility, and performance — especially for highly interactive products.",
      quote: "Build something people love to use.",
    },
    skills: {
      title: "Skills",
      desc: "Tech I use daily — and what I used in the projects below.",
    },
    projects: {
      title: "Featured projects",
      desc: "Three strong projects: an interactive game, a smart chat builder, and a real-time social platform.",
      openLocal: "Open locally",
      live: "Live",
      github: "GitHub",
      readme: "Readme",
      note: { roleK: "Role:", challengeK: "Challenge:", outcomeK: "Outcome:" },
      noteTitle: "Note",
      noteText: "Want more details on any project (my role, challenges, or a demo)? Message me and I’ll share everything.",
      cityshift: {
        subtitle: "2D driving game with realistic HUD, autodrive, and a map overlay.",
        roleV: "Built the entire game experience, HUD, menus, and interactions.",
        challengeV: "Tuning driving feel/physics while keeping the HUD smooth and responsive.",
        outcomeV: "Fast, interactive gameplay with a map overlay and autodrive.",
      },
      chatforge: {
        subtitle: "Custom chat builder + import/export + stats + favorites + AI summary.",
        roleV: "Designed and built a multi-view UI with state management and local storage.",
        challengeV: "Structuring chats, search, and favorites without a backend while keeping UX snappy.",
        outcomeV: "A feature-rich tool: import/export, stats, summaries, and image generation.",
      },
      neuraconnect: {
        subtitle: "Real-time social platform: stories, posts, meetings + WebSocket + AI features.",
        roleV: "Implemented core features: auth, feed, stories, and real-time meetings.",
        challengeV: "Synchronizing meeting events over WebSocket while maintaining stable UI/UX.",
        outcomeV: "A scalable foundation with live meetings, AI features, and a clear structure.",
      },
    },
    contact: {
      title: "Contact",
      desc: "Got a role or a new project? Send a short brief — I reply fast.",
      quick: "Quick contact",
      email: "Email",
      location: "Location",
      locationValue: "Egypt",
      addLinks: "(add your link)",
    },
    form: {
      name: "Name",
      email: "Email",
      message: "Message",
      send: "Send",
      hint: "This form opens your email client (no backend). Want real sending via EmailJS/server? Tell me.",
    },
    footer: { backTop: "Back to top" },
  },
};

function setLang(lang) {
  const isEn = lang === "en";
  document.documentElement.lang = lang;
  document.documentElement.dir = isEn ? "ltr" : "rtl";
  document.body.dataset.lang = lang;

  const dict = i18n[lang];
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.getAttribute("data-i18n");
    const value = key.split(".").reduce((acc, part) => (acc ? acc[part] : undefined), dict);
    if (typeof value === "string") el.textContent = value;
  });

  const btn = document.getElementById("langToggle");
  if (btn) btn.querySelector(".chip__text").textContent = isEn ? "AR" : "EN";

  localStorage.setItem("portfolio_lang", lang);
}

function initLang() {
  const saved = localStorage.getItem("portfolio_lang");
  const defaultLang = saved || "ar";
  setLang(defaultLang);
}

function initYear() {
  const y = document.getElementById("year");
  if (y) y.textContent = String(new Date().getFullYear());
}

function initSmoothAnchors() {
  document.querySelectorAll('a[href^="#"]').forEach((a) => {
    a.addEventListener("click", (e) => {
      const href = a.getAttribute("href");
      if (!href || href === "#") return;
      const el = document.querySelector(href);
      if (!el) return;
      e.preventDefault();
      el.scrollIntoView({ behavior: "smooth", block: "start" });
      history.replaceState(null, "", href);
    });
  });
}

function initContactForm() {
  const form = document.getElementById("contactForm");
  if (!form) return;

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const data = new FormData(form);
    const name = String(data.get("name") || "").trim();
    const email = String(data.get("email") || "").trim();
    const message = String(data.get("message") || "").trim();

    const subject = encodeURIComponent(`Portfolio inquiry — ${name}`);
    const body = encodeURIComponent(`Name: ${name}\nEmail: ${email}\n\n${message}`);

    window.location.href = `mailto:john@example.com?subject=${subject}&body=${body}`;
  });
}

document.addEventListener("DOMContentLoaded", () => {
  initYear();
  initLang();
  initSmoothAnchors();
  initContactForm();

  const toggle = document.getElementById("langToggle");
  if (toggle) {
    toggle.addEventListener("click", () => {
      const current = document.documentElement.lang === "en" ? "en" : "ar";
      setLang(current === "en" ? "ar" : "en");
    });
  }
});
