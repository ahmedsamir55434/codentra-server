import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  FlatList,
  Alert,
  Modal,
  TextInput,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Notifications from 'expo-notifications';
import { format } from 'date-fns';

interface Reminder {
  id: string;
  message: string;
  date: string;
  time: string;
  datetimeISO: string;
  notificationIds: string[];
  createdAt: string;
}

const STORAGE_KEY = 'smart_reminder_reminders_v1';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

const toWesternDigits = (value: string) => {
  const arabicIndic = '٠١٢٣٤٥٦٧٨٩';
  const easternArabicIndic = '۰۱۲۳۴۵۶۷۸۹';

  return value
    .split('')
    .map((ch) => {
      const a = arabicIndic.indexOf(ch);
      if (a >= 0) return String(a);
      const e = easternArabicIndic.indexOf(ch);
      if (e >= 0) return String(e);
      return ch;
    })
    .join('');
};

const pad2 = (n: number) => String(n).padStart(2, '0');

const parseDateTimeToISO = (dateRaw: string, timeRaw: string): string | null => {
  const date = toWesternDigits(dateRaw).trim().replace(/\//g, '-');
  const time = toWesternDigits(timeRaw).trim();

  // Accept YYYY-MM-DD
  let year: number | null = null;
  let month: number | null = null;
  let day: number | null = null;

  const ymd = date.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  if (ymd) {
    year = Number(ymd[1]);
    month = Number(ymd[2]);
    day = Number(ymd[3]);
  }

  // Accept DD-MM-YYYY
  const dmy = date.match(/^(\d{1,2})-(\d{1,2})-(\d{4})$/);
  if (!ymd && dmy) {
    day = Number(dmy[1]);
    month = Number(dmy[2]);
    year = Number(dmy[3]);
  }

  const hm = time.match(/^(\d{1,2}):(\d{2})$/);
  if (!year || !month || !day || !hm) return null;

  const hour = Number(hm[1]);
  const minute = Number(hm[2]);
  if (month < 1 || month > 12) return null;
  if (day < 1 || day > 31) return null;
  if (hour < 0 || hour > 23) return null;
  if (minute < 0 || minute > 59) return null;

  const iso = `${year}-${pad2(month)}-${pad2(day)}T${pad2(hour)}:${pad2(minute)}:00`;
  const parsed = new Date(iso);
  if (Number.isNaN(parsed.getTime())) return null;
  return iso;
};

export default function HomeScreen() {
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [message, setMessage] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');

  const openAddModal = () => {
    const now = new Date();
    setSelectedDate(`${now.getFullYear()}-${pad2(now.getMonth() + 1)}-${pad2(now.getDate())}`);
    setSelectedTime(`${pad2(now.getHours())}:${pad2(now.getMinutes())}`);
    setModalVisible(true);
  };

  const setAfterFiveMinutes = () => {
    const dt = new Date(Date.now() + 5 * 60 * 1000);
    setSelectedDate(`${dt.getFullYear()}-${pad2(dt.getMonth() + 1)}-${pad2(dt.getDate())}`);
    setSelectedTime(`${pad2(dt.getHours())}:${pad2(dt.getMinutes())}`);
  };

  useEffect(() => {
    loadReminders();
    void requestNotificationPermissions();
  }, []);

  const requestNotificationPermissions = async () => {
    try {
      const settings = await Notifications.getPermissionsAsync();
      if (settings.granted) return;
      const req = await Notifications.requestPermissionsAsync();
      if (!req.granted) {
        Alert.alert('تنبيه', 'يجب تفعيل الإشعارات ليعمل التذكير في الموعد');
      }
    } catch (e) {
      console.error('Notification permission error:', e);
    }
  };

  const loadReminders = async () => {
    try {
      const stored = await AsyncStorage.getItem(STORAGE_KEY);
      if (!stored) {
        setReminders([]);
        return;
      }
      const parsed = JSON.parse(stored) as Reminder[];
      setReminders(Array.isArray(parsed) ? parsed : []);
    } catch (error) {
      console.error('Error loading reminders:', error);
      setReminders([]);
    }
  };

  const saveReminders = async (newReminders: Reminder[]) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(newReminders));
      setReminders(newReminders);
    } catch (error) {
      console.error('Error saving reminders:', error);
    }
  };

  const scheduleOne = async (date: Date, title: string, body: string) => {
    // iOS requires at least 1 second in the future
    const seconds = Math.max(1, Math.floor((date.getTime() - Date.now()) / 1000));
    const trigger: Notifications.NotificationTriggerInput = {
      type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL,
      seconds,
      repeats: false,
    };

    return Notifications.scheduleNotificationAsync({
      content: {
        title,
        body,
        sound: 'default',
      },
      trigger,
    });
  };

  const scheduleForReminder = async (reminderMessage: string, when: Date) => {
    const ids: string[] = [];
    const fiveMin = new Date(when.getTime() - 5 * 60 * 1000);
    const thirtyMin = new Date(when.getTime() - 30 * 60 * 1000);

    if (fiveMin.getTime() > Date.now()) {
      ids.push(await scheduleOne(fiveMin, '⏰ تذكير بعد 5 دقائق', reminderMessage));
    }
    if (thirtyMin.getTime() > Date.now()) {
      ids.push(await scheduleOne(thirtyMin, '⏰ تذكير بعد 30 دقيقة', reminderMessage));
    }
    if (when.getTime() > Date.now()) {
      ids.push(await scheduleOne(when, '⏰ الوقت الآن!', reminderMessage));
    }

    return ids;
  };

  const addReminder = async () => {
    if (!message.trim() || !selectedDate || !selectedTime) {
      Alert.alert('خطأ', 'الرجاء ملء جميع الحقول');
      return;
    }

    const datetimeISO = parseDateTimeToISO(selectedDate, selectedTime);
    if (!datetimeISO) {
      Alert.alert('خطأ', 'صيغة التاريخ أو الوقت غير صحيحة');
      return;
    }

    const safeDate = datetimeISO.slice(0, 10);
    const safeTime = datetimeISO.slice(11, 16);

    const when = new Date(datetimeISO);
    if (Number.isNaN(when.getTime()) || when.getTime() <= Date.now()) {
      Alert.alert('خطأ', 'الرجاء اختيار موعد في المستقبل');
      return;
    }

    let notificationIds: string[] = [];
    try {
      notificationIds = await scheduleForReminder(message.trim(), when);
    } catch (e) {
      // In Expo Go / misconfigured build scheduling might fail
      console.error('Schedule notification error:', e);
      Alert.alert('تنبيه', 'لم يتم جدولة الإشعارات. استخدم Development Build لتعمل بشكل كامل.');
    }

    const newReminder: Reminder = {
      id: Date.now().toString(),
      message: message.trim(),
      date: safeDate,
      time: safeTime,
      datetimeISO,
      notificationIds,
      createdAt: new Date().toISOString(),
    };

    const newReminders = [...reminders, newReminder];
    await saveReminders(newReminders);

    // Reset form
    setMessage('');
    setSelectedDate('');
    setSelectedTime('');
    setModalVisible(false);

    Alert.alert('نجاح', 'تم إضافة التذكير بنجاح');
  };

  const deleteReminder = async (id: string) => {
    Alert.alert(
      'حذف التذكير',
      'هل أنت متأكد من حذف هذا التذكير؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'حذف',
          style: 'destructive',
          onPress: async () => {
            const target = reminders.find((r) => r.id === id);
            if (target?.notificationIds?.length) {
              await Promise.all(
                target.notificationIds.map((nid) => Notifications.cancelScheduledNotificationAsync(nid))
              ).catch((e) => console.error('Cancel notification error:', e));
            }

            const newReminders = reminders.filter(r => r.id !== id);
            await saveReminders(newReminders);
          },
        },
      ]
    );
  };

  const renderReminder = ({ item }: { item: Reminder }) => {
    try {
      const reminderDate = new Date(item.datetimeISO);
      if (isNaN(reminderDate.getTime())) {
        return null;
      }
      
      return (
        <View style={styles.reminderItem}>
          <View style={styles.reminderContent}>
            <Text style={styles.reminderMessage}>{item.message}</Text>
            <Text style={styles.reminderTime}>
              {format(reminderDate, 'dd/MM/yyyy HH:mm')}
            </Text>
          </View>
          <TouchableOpacity
            style={styles.deleteButton}
            onPress={() => deleteReminder(item.id)}
          >
            <Text style={styles.deleteButtonText}>🗑️</Text>
          </TouchableOpacity>
        </View>
      );
    } catch (error) {
      console.error('Error rendering reminder:', error);
      return null;
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>⏰ Smart Reminder</Text>
        <Text style={styles.subtitle}>لا تنسى أي مهمة مهمة</Text>
      </View>

      <FlatList
        data={reminders}
        renderItem={renderReminder}
        keyExtractor={(item) => item.id}
        style={styles.list}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Text style={styles.emptyText}>لا توجد تذكيرات بعد</Text>
            <Text style={styles.emptySubtext}>اضغط على + لإضافة تذكير جديد</Text>
          </View>
        }
      />

      <TouchableOpacity
        style={styles.addButton}
        onPress={openAddModal}
      >
        <Text style={styles.addButtonText}>+</Text>
      </TouchableOpacity>

      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>إضافة تذكير جديد</Text>
            
            <TextInput
              style={styles.input}
              placeholder="اكتب رسالتك هنا..."
              value={message}
              onChangeText={setMessage}
              multiline
              textAlign="right"
              textAlignVertical="top"
            />

            <TextInput
              style={styles.input}
              placeholder="التاريخ (YYYY-MM-DD)"
              value={selectedDate}
              onChangeText={setSelectedDate}
              textAlign="right"
            />

            <TextInput
              style={styles.input}
              placeholder="الوقت (HH:MM)"
              value={selectedTime}
              onChangeText={setSelectedTime}
              textAlign="right"
            />

            <View style={styles.quickRow}>
              <TouchableOpacity style={styles.quickButton} onPress={setAfterFiveMinutes}>
                <Text style={styles.quickButtonText}>بعد 5 دقائق</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.button, styles.cancelButton]}
                onPress={() => setModalVisible(false)}
              >
                <Text style={styles.buttonText}>إلغاء</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.button, styles.saveButton]}
                onPress={addReminder}
              >
                <Text style={styles.buttonText}>حفظ</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    paddingTop: 50,
  },
  header: {
    backgroundColor: '#007AFF',
    padding: 30,
    alignItems: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 16,
    color: '#fff',
    opacity: 0.9,
  },
  list: {
    flex: 1,
    padding: 15,
  },
  reminderItem: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  reminderContent: {
    flex: 1,
  },
  reminderMessage: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
    color: '#333',
    textAlign: 'right',
  },
  reminderTime: {
    fontSize: 14,
    color: '#666',
    textAlign: 'right',
  },
  deleteButton: {
    padding: 10,
  },
  deleteButtonText: {
    fontSize: 20,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 100,
  },
  emptyText: {
    fontSize: 18,
    color: '#666',
    marginBottom: 5,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#999',
  },
  addButton: {
    position: 'absolute',
    bottom: 30,
    right: 30,
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#007AFF',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  addButtonText: {
    fontSize: 30,
    color: '#fff',
    fontWeight: 'bold',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    width: '90%',
    maxHeight: '80%',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#333',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 15,
    fontSize: 16,
    marginBottom: 15,
    textAlign: 'right',
    textAlignVertical: 'top',
  },
  quickRow: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginBottom: 15,
  },
  quickButton: {
    backgroundColor: '#EEF5FF',
    borderWidth: 1,
    borderColor: '#BBD7FF',
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 8,
  },
  quickButtonText: {
    color: '#007AFF',
    fontSize: 14,
    fontWeight: '600',
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  button: {
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    width: '45%',
  },
  cancelButton: {
    backgroundColor: '#FF3B30',
  },
  saveButton: {
    backgroundColor: '#34C759',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
