import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Image,
  Alert,
  ActivityIndicator,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';

export default function HomeScreen() {
  const [selectedImages, setSelectedImages] = useState([]);
  const [textInput, setTextInput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  const pickImages = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsMultipleSelection: true,
      quality: 1,
    });

    if (!result.canceled) {
      setSelectedImages(result.assets);
    }
  };

  const generatePDFFromImages = async () => {
    if (selectedImages.length === 0) {
      Alert.alert('خطأ', 'الرجاء اختيار صورة واحدة على الأقل');
      return;
    }

    setIsGenerating(true);
    try {
      let html = '<html><body style="text-align: center; direction: rtl;">';
      html += '<h1>ملف PDF من الصور</h1>';
      
      for (const image of selectedImages) {
        html += `<div style="margin: 20px 0;">`;
        html += `<img src="${image.uri}" style="max-width: 100%; height: auto;" />`;
        html += `</div>`;
      }
      
      html += '</body></html>';

      const { uri } = await Print.printToFileAsync({
        html,
        base64: false,
      });

      await Sharing.shareAsync(uri, {
        mimeType: 'application/pdf',
        dialogTitle: 'مشاركة ملف PDF',
      });
    } catch (error) {
      Alert.alert('خطأ', 'فشل إنشاء ملف PDF');
      console.error(error);
    } finally {
      setIsGenerating(false);
    }
  };

  const generatePDFFromText = async () => {
    if (!textInput.trim()) {
      Alert.alert('خطأ', 'الرجاء إدخال نص');
      return;
    }

    setIsGenerating(true);
    try {
      const html = `
        <html>
          <head>
            <meta charset="UTF-8">
            <style>
              body { 
                font-family: Arial, sans-serif; 
                padding: 20px; 
                line-height: 1.6; 
                direction: rtl; 
                text-align: right;
              }
              h1 { color: #333; }
            </style>
          </head>
          <body>
            <h1>ملف PDF من النص</h1>
            <p>${textInput.replace(/\n/g, '<br>')}</p>
          </body>
        </html>
      `;

      const { uri } = await Print.printToFileAsync({
        html,
        base64: false,
      });

      await Sharing.shareAsync(uri, {
        mimeType: 'application/pdf',
        dialogTitle: 'مشاركة ملف PDF',
      });
    } catch (error) {
      Alert.alert('خطأ', 'فشل إنشاء ملف PDF');
      console.error(error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>محول PDF</Text>
        <Text style={styles.subtitle}>حول الصور والنصوص إلى ملف PDF</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>📷 تحويل الصور إلى PDF</Text>
        
        <TouchableOpacity style={styles.button} onPress={pickImages}>
          <Text style={styles.buttonText}>اختر صور</Text>
        </TouchableOpacity>

        {selectedImages.length > 0 && (
          <View style={styles.imageContainer}>
            <Text style={styles.imageCount}>تم اختيار {selectedImages.length} صور</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              {selectedImages.map((image, index) => (
                <Image key={index} source={{ uri: image.uri }} style={styles.thumbnail} />
              ))}
            </ScrollView>
            
            <TouchableOpacity 
              style={[styles.button, styles.generateButton]} 
              onPress={generatePDFFromImages}
              disabled={isGenerating}
            >
              {isGenerating ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={styles.buttonText}>إنشاء PDF من الصور</Text>
              )}
            </TouchableOpacity>
          </View>
        )}
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>📝 تحويل النص إلى PDF</Text>
        
        <TextInput
          style={styles.textInput}
          multiline
          placeholder="اكتب النص هنا..."
          value={textInput}
          onChangeText={setTextInput}
          textAlign="right"
          textAlignVertical="top"
        />

        <TouchableOpacity 
          style={[styles.button, styles.generateButton]} 
          onPress={generatePDFFromText}
          disabled={isGenerating}
        >
          {isGenerating ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.buttonText}>إنشاء PDF من النص</Text>
          )}
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#007AFF',
    padding: 30,
    alignItems: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 16,
    color: '#fff',
    opacity: 0.9,
  },
  section: {
    backgroundColor: '#fff',
    margin: 15,
    padding: 20,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#333',
  },
  button: {
    backgroundColor: '#007AFF',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 10,
  },
  generateButton: {
    backgroundColor: '#34C759',
    marginTop: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  imageContainer: {
    marginTop: 15,
  },
  imageCount: {
    fontSize: 14,
    color: '#666',
    marginBottom: 10,
    textAlign: 'center',
  },
  thumbnail: {
    width: 80,
    height: 80,
    borderRadius: 8,
    marginHorizontal: 5,
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 15,
    fontSize: 16,
    minHeight: 150,
    textAlign: 'right',
    textAlignVertical: 'top',
    marginBottom: 10,
  },
});
