// ChatForge - تكامل Gemini API
// ملف منفصل لإعدادات Gemini API الفعلية

console.log('🔧 تم تحميل Gemini Integration مع المفتاح المدمج');

// إعدادات Gemini API
const GEMINI_CONFIG = {
    API_KEY: 'AIzaSyCQ0iJwgKME8LyxG7jR3EhpGF4RCnu2SxA', // مفتاح API المحفوظ
    MODEL: 'gemini-2.0-flash-exp',
    MODEL_VISION: 'gemini-2.0-flash-exp',
    BASE_URL: 'https://generativelanguage.googleapis.com/v1beta/models',
    MAX_TOKENS: 1024,
    TEMPERATURE: 0.7,
    TOP_K: 40,
    TOP_P: 0.95
};

// دالة محسنة للحصول على رد من Gemini API
async function getGeminiResponse(message, images = []) {
    // التحقق من وجود مفتاح API
    if (!GEMINI_CONFIG.API_KEY || GEMINI_CONFIG.API_KEY === '') {
        throw new Error('❌ لا يوجد مفتاح Gemini API. يرجى التحقق من الإعدادات.');
    }
    
    // التحقق من صحة مفتاح API
    if (!GEMINI_CONFIG.API_KEY.startsWith('AIza')) {
        console.warn('⚠️ تحذير: مفتاح API قد يكون غير صحيح');
    }
    
    const chat = chats.find(c => c.id === currentChatId);
    if (!chat) throw new Error('الشات غير موجود');
    
    const hasImages = images && images.length > 0;
    const modelToUse = hasImages ? GEMINI_CONFIG.MODEL_VISION : GEMINI_CONFIG.MODEL;
    
    console.log('🚀 استخدام Gemini API الحقيقي مع النموذج:', modelToUse);
    console.log('🎭 شخصية الشات:', chat.name);
    console.log('📝 وصف الشخصية:', chat.description);
    if (hasImages) {
        console.log('🖼️ عدد الصور المرفقة:', images.length);
    }
    
    // بناء المحادثة السابقة للسياق
    const conversationHistory = buildConversationHistory(chat);
    
    // إنشاء الـ prompt مع معلومات إضافية للصور
    let prompt = createPrompt(chat.description, conversationHistory, message);
    
    if (hasImages) {
        const imageText = images.length === 1 ? 'صورة واحدة' : `${images.length} صور`;
        prompt = `${prompt}\n\n📸 تم إرفاق ${imageText}. يرجى تحليل الصور المرفقة بعناية والرد بناءً على المحتوى المرئي${message ? ' مع الأخذ في الاعتبار السؤال أو التعليق المرفق' : ''}.`;
    }
    
    console.log('📤 إرسال الطلب مع السياق الكامل إلى Gemini API...');
    
    // إرسال الطلب إلى Gemini API
    const response = await callGeminiAPI(prompt, images);
    
    console.log('✅ تم استلام الرد من Gemini API بنجاح');
    console.log('🎯 الرد مخصص لشخصية:', chat.name);
    return response;
}

// بناء تاريخ المحادثة للسياق
function buildConversationHistory(chat) {
    const recentMessages = chat.messages.slice(-10); // آخر 10 رسائل
    
    if (recentMessages.length === 0) {
        return 'لا توجد محادثة سابقة - هذه بداية المحادثة';
    }
    
    return recentMessages.map((msg, index) => {
        const sender = msg.sender === 'user' ? 'المستخدم' : 'أنت (بناءً على شخصيتك المحددة)';
        const time = new Date(msg.timestamp).toLocaleTimeString('ar-SA', { 
            hour: '2-digit', 
            minute: '2-digit' 
        });
        return `${index + 1}. ${sender} (${time}): ${msg.content}`;
    }).join('\n');
}

// إنشاء الـ prompt المناسب
function createPrompt(description, history, currentMessage) {
    return `
أنت مساعد ذكي مصمم خصيصاً للمستخدم. مهمتك الأساسية هي:

🎯 **شخصيتك المحددة:**
${description}

📚 **تاريخ المحادثة:**
${history}

💬 **رسالة المستخدم الحالية:** 
${currentMessage}

🔑 **تعليمات مهمة:**
- تذكر دائماً أن شخصيتك هي: "${description}"
- أجب بناءً على هذا الوصف بالضبط
- كن متسقاً مع الشخصية المحددة في كل رد
- استخدم اللغة العربية الفصحى أو العامية حسب السياق
- كن مفيداً ودقيقاً ومتخصصاً في المجال المحدد
- إذا كان السؤال خارج اختصاصك، أشر إلى ذلك بلطف
- اجعل إجابتك مختصرة ومفيدة ومناسبة لشخصيتك
- تذكر أن المستخدم اختار هذه الشخصية خصيصاً للمساعدة في: "${description}"

⚡ **رد الآن بناءً على شخصيتك المحددة أعلاه:**
`;
}

// استدعاء Gemini API
async function callGeminiAPI(prompt, images = []) {
    const hasImages = images && images.length > 0;
    const modelToUse = hasImages ? GEMINI_CONFIG.MODEL_VISION : GEMINI_CONFIG.MODEL;
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${modelToUse}:generateContent?key=${GEMINI_CONFIG.API_KEY}`;
    
    // بناء أجزاء المحتوى (نص + صور)
    const parts = [];
    
    // إضافة الصور أولاً
    if (hasImages) {
        images.forEach(imageData => {
            // إزالة البادئة data:image/...;base64, من البيانات
            const base64Data = imageData.split(',')[1];
            const mimeType = imageData.split(';')[0].split(':')[1];
            
            parts.push({
                inlineData: {
                    mimeType: mimeType,
                    data: base64Data
                }
            });
        });
    }
    
    // إضافة النص
    parts.push({
        text: prompt
    });
    
    const requestBody = {
        contents: [{
            parts: parts
        }],
        generationConfig: {
            temperature: GEMINI_CONFIG.TEMPERATURE,
            topK: GEMINI_CONFIG.TOP_K,
            topP: GEMINI_CONFIG.TOP_P,
            maxOutputTokens: GEMINI_CONFIG.MAX_TOKENS,
        },
        safetySettings: [
            {
                category: "HARM_CATEGORY_HARASSMENT",
                threshold: "BLOCK_MEDIUM_AND_ABOVE"
            },
            {
                category: "HARM_CATEGORY_HATE_SPEECH",
                threshold: "BLOCK_MEDIUM_AND_ABOVE"
            },
            {
                category: "HARM_CATEGORY_SEXUALLY_EXPLICIT",
                threshold: "BLOCK_MEDIUM_AND_ABOVE"
            },
            {
                category: "HARM_CATEGORY_DANGEROUS_CONTENT",
                threshold: "BLOCK_MEDIUM_AND_ABOVE"
            }
        ]
    };
    
    const response = await fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody)
    });
    
    if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        const errorMsg = errorData.error?.message || 'خطأ غير معروف';
        
        if (response.status === 400) {
            throw new Error(`❌ خطأ في الطلب: ${errorMsg}`);
        } else if (response.status === 403) {
            throw new Error('❌ مفتاح API غير صالح أو منتهي الصلاحية. يرجى التحقق من المفتاح.');
        } else if (response.status === 429) {
            throw new Error('⏳ تم تجاوز حد الطلبات. يرجى الانتظار قليلاً والمحاولة مرة أخرى.');
        } else if (response.status === 500) {
            throw new Error('❌ خطأ في خادم Gemini. يرجى المحاولة لاحقاً.');
        } else {
            throw new Error(`❌ خطأ في API (${response.status}): ${errorMsg}`);
        }
    }
    
    const data = await response.json();
    
    if (!data.candidates || data.candidates.length === 0) {
        throw new Error('⚠️ لم يتم إنتاج رد من Gemini API. قد يكون المحتوى محظوراً أو حدث خطأ.');
    }
    
    const generatedText = data.candidates[0].content.parts[0].text;
    return generatedText.trim();
}

// تم إزالة الردود التجريبية - الآن يتم استخدام Gemini API فقط!

// دالة لإعداد API Key
function setGeminiAPIKey(apiKey) {
    GEMINI_CONFIG.API_KEY = apiKey;
    localStorage.setItem('gemini_api_key', apiKey);
    console.log('تم حفظ Gemini API Key بنجاح');
}

// دالة لتحميل API Key من localStorage
function loadGeminiAPIKey() {
    const choice = localStorage.getItem('api_choice') || 'builtin';
    
    if (choice === 'custom') {
        const savedKey = localStorage.getItem('gemini_api_key');
        if (savedKey) {
            GEMINI_CONFIG.API_KEY = savedKey;
            console.log('🔑 تم تحميل مفتاح API المخصص من التخزين المحلي');
        } else {
            console.log('⚠️ تم اختيار API مخصص لكن لا يوجد مفتاح محفوظ، سيتم استخدام المدمج');
            GEMINI_CONFIG.API_KEY = 'AIzaSyCQ0iJwgKME8LyxG7jR3EhpGF4RCnu2SxA';
        }
    } else {
        GEMINI_CONFIG.API_KEY = 'AIzaSyCQ0iJwgKME8LyxG7jR3EhpGF4RCnu2SxA';
        console.log('🔧 تم استخدام مفتاح API المدمج');
    }
}

// دالة لاختبار الاتصال بـ Gemini API
async function testGeminiConnection() {
    if (!GEMINI_CONFIG.API_KEY) {
        return { success: false, message: 'API Key غير محدد' };
    }
    
    try {
        console.log('🧪 اختبار الاتصال بـ Gemini API...');
        const testPrompt = 'مرحباً، هذا اختبار للاتصال. أجب بكلمة واحدة فقط: "نجح"';
        const response = await callGeminiAPI(testPrompt);
        console.log('✅ اختبار الاتصال نجح!');
        return { success: true, message: 'الاتصال ناجح', response: response };
    } catch (error) {
        console.error('❌ اختبار الاتصال فشل:', error);
        return { success: false, message: error.message };
    }
}

// دالة لإظهار نافذة إعدادات API
function showAPISettings() {
    const modal = document.createElement('div');
    modal.className = 'modal show';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h2>إعدادات Gemini API</h2>
                <button class="close-button" onclick="this.closest('.modal').remove()">×</button>
            </div>
            <div class="modal-body">
                <div class="api-choice-section">
                    <h3>اختر مصدر API:</h3>
                    
                    <div class="choice-option">
                        <input type="radio" id="use-builtin-api" name="api-choice" value="builtin" checked>
                        <label for="use-builtin-api">
                            <strong>استخدام API المدمج (موصى به)</strong>
                            <small>يستخدم مفتاح API محفوظ مسبقاً - سريع وسهل</small>
                        </label>
                    </div>
                    
                    <div class="choice-option">
                        <input type="radio" id="use-custom-api" name="api-choice" value="custom">
                        <label for="use-custom-api">
                            <strong>استخدام مفتاح API الخاص بك</strong>
                            <small>أدخل مفتاح API الخاص بك من Google AI Studio</small>
                        </label>
                    </div>
                </div>
                
                <div id="custom-api-section" class="input-section hidden">
                    <div class="input-group">
                        <label for="api-key-input">مفتاح Gemini API</label>
                        <input type="password" id="api-key-input" placeholder="أدخل مفتاح API هنا" />
                        <small>يمكنك الحصول على المفتاح من <a href="https://makersuite.google.com/app/apikey" target="_blank">Google AI Studio</a></small>
                    </div>
                </div>
                
                <div class="current-api-info">
                    <strong>API الحالي:</strong>
                    <span id="current-api-info">تحميل...</span>
                </div>
                
                <div id="api-status" class="api-status"></div>
            </div>
            <div class="modal-footer">
                <button class="secondary-button" onclick="this.closest('.modal').remove()">إلغاء</button>
                <button class="primary-button" onclick="saveAPISettings()">حفظ الإعدادات</button>
                <button class="primary-button" onclick="testAPI()">اختبار الاتصال</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // إعداد مستمعي الأحداث
    const builtinRadio = document.getElementById('use-builtin-api');
    const customRadio = document.getElementById('use-custom-api');
    const customSection = document.getElementById('custom-api-section');
    
    builtinRadio.addEventListener('change', function() {
        if (this.checked) {
            customSection.classList.add('hidden');
            updateCurrentAPIInfo();
        }
    });
    
    customRadio.addEventListener('change', function() {
        if (this.checked) {
            customSection.classList.remove('hidden');
            updateCurrentAPIInfo();
        }
    });
    
    // تحميل المفتاح المحفوظ
    const savedKey = localStorage.getItem('gemini_api_key');
    const savedChoice = localStorage.getItem('api_choice') || 'builtin';
    
    if (savedChoice === 'custom' && savedKey) {
        customRadio.checked = true;
        customSection.classList.remove('hidden');
        document.getElementById('api-key-input').value = savedKey;
    } else {
        builtinRadio.checked = true;
        customSection.classList.add('hidden');
    }
    
    updateCurrentAPIInfo();
}

// دالة لحفظ إعدادات API
function saveAPISettings() {
    const choice = document.querySelector('input[name="api-choice"]:checked').value;
    const statusDiv = document.getElementById('api-status');
    
    if (choice === 'builtin') {
        // استخدام API المدمج
        localStorage.setItem('api_choice', 'builtin');
        localStorage.removeItem('gemini_api_key'); // إزالة المفتاح المخصص
        GEMINI_CONFIG.API_KEY = 'AIzaSyCQ0iJwgKME8LyxG7jR3EhpGF4RCnu2SxA'; // العودة للمفتاح المدمج
        
        statusDiv.innerHTML = '<div style="color: #00d4ff; margin-top: 10px;">✓ تم تفعيل API المدمج بنجاح</div>';
        console.log('🔧 تم تفعيل API المدمج');
        updateAPIIndicator();
    } else {
        // استخدام API مخصص
        const apiKey = document.getElementById('api-key-input').value.trim();
        
        if (!apiKey) {
            statusDiv.innerHTML = '<div style="color: #ff4444; margin-top: 10px;">❌ يرجى إدخال مفتاح API</div>';
            return;
        }
        
        localStorage.setItem('api_choice', 'custom');
        setGeminiAPIKey(apiKey);
        statusDiv.innerHTML = '<div style="color: #00d4ff; margin-top: 10px;">✓ تم حفظ مفتاح API المخصص بنجاح</div>';
        console.log('🔧 تم تفعيل API المخصص');
        updateAPIIndicator();
    }
    
    updateCurrentAPIInfo();
}

// دالة لتحديث معلومات API الحالي
function updateCurrentAPIInfo() {
    const infoSpan = document.getElementById('current-api-info');
    if (!infoSpan) return;
    
    const choice = localStorage.getItem('api_choice') || 'builtin';
    
    if (choice === 'builtin') {
        infoSpan.innerHTML = '<span style="color: #00d4ff;">🔧 API المدمج (موصى به)</span>';
    } else {
        const customKey = localStorage.getItem('gemini_api_key');
        if (customKey) {
            infoSpan.innerHTML = `<span style="color: #00ff00;">🔑 مفتاحك الخاص (${customKey.substring(0, 10)}...)</span>`;
        } else {
            infoSpan.innerHTML = '<span style="color: #ffaa00;">⚠️ لا يوجد مفتاح مخصص</span>';
        }
    }
}

// دالة لاختبار API
async function testAPI() {
    const choice = document.querySelector('input[name="api-choice"]:checked').value;
    const statusDiv = document.getElementById('api-status');
    
    statusDiv.innerHTML = '<div style="color: #ffa500; margin-top: 10px;">🔄 جاري اختبار الاتصال...</div>';
    
    try {
        if (choice === 'builtin') {
            // اختبار API المدمج
            const originalKey = GEMINI_CONFIG.API_KEY;
            GEMINI_CONFIG.API_KEY = 'AIzaSyCQ0iJwgKME8LyxG7jR3EhpGF4RCnu2SxA';
            
            const result = await testGeminiConnection();
            
            if (result.success) {
                statusDiv.innerHTML = `<div style="color: #00d4ff; margin-top: 10px;">✓ ${result.message} - API المدمج يعمل بشكل ممتاز!</div>`;
            } else {
                statusDiv.innerHTML = `<div style="color: #ff4444; margin-top: 10px;">✗ ${result.message}</div>`;
            }
            
            GEMINI_CONFIG.API_KEY = originalKey;
        } else {
            // اختبار API مخصص
            const apiKey = document.getElementById('api-key-input').value.trim();
            
            if (!apiKey) {
                statusDiv.innerHTML = '<div style="color: #ff4444; margin-top: 10px;">❌ يرجى إدخال مفتاح API أولاً</div>';
                return;
            }
            
            const originalKey = GEMINI_CONFIG.API_KEY;
            GEMINI_CONFIG.API_KEY = apiKey;
            
            const result = await testGeminiConnection();
            
            if (result.success) {
                statusDiv.innerHTML = `<div style="color: #00d4ff; margin-top: 10px;">✓ ${result.message} - مفتاحك الخاص يعمل بشكل ممتاز!</div>`;
            } else {
                statusDiv.innerHTML = `<div style="color: #ff4444; margin-top: 10px;">✗ ${result.message}</div>`;
            }
            
            GEMINI_CONFIG.API_KEY = originalKey;
        }
    } catch (error) {
        statusDiv.innerHTML = `<div style="color: #ff4444; margin-top: 10px;">✗ خطأ في الاختبار: ${error.message}</div>`;
    }
}

// تحميل إعدادات API عند بدء التطبيق
document.addEventListener('DOMContentLoaded', function() {
    loadGeminiAPIKey();
    
    // إضافة زر إعدادات API للـ header
    const chatHeader = document.querySelector('.chat-header');
    if (chatHeader) {
        const settingsButton = document.createElement('button');
        settingsButton.className = 'action-button';
        settingsButton.innerHTML = '⚙️ API';
        settingsButton.title = 'إعدادات Gemini API';
        settingsButton.onclick = showAPISettings;
        
        const chatActions = chatHeader.querySelector('.chat-actions');
        if (chatActions) {
            chatActions.appendChild(settingsButton);
        }
        
        // إضافة مؤشر نوع API
        const apiIndicator = document.createElement('div');
        apiIndicator.id = 'api-indicator';
        apiIndicator.style.cssText = `
            position: absolute;
            top: 5px;
            right: 5px;
            font-size: 0.7rem;
            padding: 2px 6px;
            border-radius: 10px;
            background: rgba(0, 212, 255, 0.2);
            color: #00d4ff;
            border: 1px solid rgba(0, 212, 255, 0.3);
        `;
        
        updateAPIIndicator();
        chatHeader.appendChild(apiIndicator);
    }
});

// دالة لتحديث مؤشر نوع API
function updateAPIIndicator() {
    const indicator = document.getElementById('api-indicator');
    if (!indicator) return;
    
    const choice = localStorage.getItem('api_choice') || 'builtin';
    
    if (choice === 'builtin') {
        indicator.innerHTML = '🔧 API مدمج';
        indicator.style.background = 'rgba(0, 212, 255, 0.2)';
        indicator.style.color = '#00d4ff';
        indicator.style.borderColor = 'rgba(0, 212, 255, 0.3)';
    } else {
        indicator.innerHTML = '🔑 API مخصص';
        indicator.style.background = 'rgba(0, 255, 0, 0.2)';
        indicator.style.color = '#00ff00';
        indicator.style.borderColor = 'rgba(0, 255, 0, 0.3)';
    }
}

// تصدير الدوال للاستخدام في الملف الرئيسي
window.GeminiIntegration = {
    getGeminiResponse,
    setGeminiAPIKey,
    testGeminiConnection,
    showAPISettings
};
