# ChatForge 🔥 - الموقع الذكي لصناعة الشاتات المخصصة

## نظرة عامة

ChatForge هو موقع ويب تفاعلي يتيح للمستخدم إنشاء شاتات ذكاء صناعي خاصة به. كل شات يتم تعريفها من خلال اسم ووصف (Description)، والوصف هو الذي يحدد "شخصية" الذكاء الصناعي وسلوكه في الردود.

## المميزات

- 🎨 **تصميم عصري وجذاب** مع تأثيرات بصرية متقدمة
- 🤖 **ذكاء صناعي مخصص** باستخدام Gemini API
- 🖼️ **توليد الصور بالذكاء الاصطناعي** - إنشاء صور مخصصة باستخدام AI (جديد!)
- 💾 **حفظ محلي** لجميع المحادثات في localStorage
- 🔒 **خصوصية كاملة** - لا يتم إرسال أي بيانات للخادم
- 📱 **تصميم متجاوب** يعمل على جميع الأجهزة
- 📸 **رفع الصور** وتحليلها بالذكاء الاصطناعي
- 🎤 **تسجيل صوتي** للرسائل
- 📊 **إحصائيات مفصلة** للاستخدام
- 💾 **تصدير المحادثات** بصيغ متعددة (TXT, PDF)
- ⚡ **أداء سريع** مع تحميل فوري

## كيفية الاستخدام

### 1. تشغيل الموقع
- افتح ملف `index.html` في متصفح الويب
- لا حاجة لتثبيت أي برامج إضافية

### 2. إنشاء شات جديد
- اضغط على زر "ابدأ الآن" في الصفحة الرئيسية
- أدخل اسم الشات (مثل: "المساعد البرمجي")
- أدخل وصف الشخصية (مثل: "ساعدني في كتابة أكواد جافاسكربت بطريقة احترافية")
- اضغط "إنشاء الشات"

### 3. إدارة المحادثات
- عرض جميع المحادثات السابقة في الصفحة الرئيسية
- النقر على أي محادثة للعودة إليها
- إمكانية تعديل أو حذف المحادثات

### 4. توليد الصور بالذكاء الاصطناعي 🎨 (جديد!)
- اضغط على زر توليد الصور (الأيقونة البنفسجية) في شريط الإدخال
- أدخل وصفاً دقيقاً للصورة التي تريد توليدها
- اختر النمط الفني المناسب (واقعي، أنمي، فني، إلخ)
- اختر حجم الصورة (512x512 إلى 1024x1024)
- اضغط "توليد الصورة" وانتظر ثواني
- يمكنك تحميل الصورة أو إضافتها مباشرة للمحادثة

**مزودو الخدمة:**
- **Pollinations.ai** (مجاني، بدون API key) - موصى به ✅
- **Stability AI** (يحتاج API key من platform.stability.ai)

📖 للمزيد من التفاصيل، راجع [دليل توليد الصور](IMAGE_GENERATION_GUIDE.md)

## إعداد Gemini API (اختياري)

للاستفادة من الذكاء الصناعي الحقيقي، يمكنك إعداد Gemini API:

### 1. الحصول على API Key
- اذهب إلى [Google AI Studio](https://makersuite.google.com/app/apikey)
- أنشئ حساب جديد أو سجل الدخول
- أنشئ API Key جديد

### 2. تحديث الكود
في ملف `script.js`، استبدل دالة `getGeminiResponse` بالكود التالي:

```javascript
async function getGeminiResponse(message) {
    const chat = chats.find(c => c.id === currentChatId);
    if (!chat) throw new Error('الشات غير موجود');
    
    const API_KEY = 'YOUR_GEMINI_API_KEY_HERE'; // ضع مفتاح API هنا
    const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${API_KEY}`;
    
    const prompt = `
    أنت ${chat.description}
    
    المحادثة السابقة:
    ${chat.messages.slice(-10).map(msg => 
        `${msg.sender === 'user' ? 'المستخدم' : 'أنت'}: ${msg.content}`
    ).join('\n')}
    
    رسالة المستخدم الحالية: ${message}
    
    أجب بطريقة طبيعية ومناسبة لشخصيتك المحددة.
    `;
    
    const requestBody = {
        contents: [{
            parts: [{
                text: prompt
            }]
        }],
        generationConfig: {
            temperature: 0.7,
            topK: 40,
            topP: 0.95,
            maxOutputTokens: 1024,
        }
    };
    
    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(requestBody)
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        return data.candidates[0].content.parts[0].text;
        
    } catch (error) {
        console.error('خطأ في API:', error);
        throw error;
    }
}
```

### 3. تحديث API Key
- استبدل `YOUR_GEMINI_API_KEY_HERE` بمفتاح API الحقيقي
- احفظ الملف وأعد تحميل الصفحة

## هيكل المشروع

```
chat-forge/
├── index.html                  # الصفحة الرئيسية
├── styles.css                  # ملف التصميم
├── script.js                   # منطق التطبيق الرئيسي
├── gemini-integration.js       # تكامل Gemini API
├── image-generation.js         # توليد الصور بالذكاء الاصطناعي (جديد!)
├── README.md                   # هذا الملف
├── IMAGE_GENERATION_GUIDE.md   # دليل توليد الصور (جديد!)
├── health-check.html           # فحص صحة النظام
└── test-api.html              # اختبار API
```

## المميزات التقنية

### التصميم
- **Glassmorphism**: تأثيرات زجاجية حديثة
- **Gradient Backgrounds**: خلفيات متدرجة جذابة
- **Responsive Design**: متوافق مع جميع أحجام الشاشات
- **Smooth Animations**: حركات سلسة ومتطورة

### الوظائف
- **Local Storage**: حفظ البيانات محلياً في المتصفح
- **Real-time Chat**: محادثة فورية مع مؤشرات الكتابة
- **Auto-resize**: تعديل حجم مربع النص تلقائياً
- **Message History**: حفظ تاريخ كامل للمحادثات
- **AI Image Generation**: توليد صور بالذكاء الاصطناعي (Pollinations.ai & Stability AI)
- **Image Upload & Analysis**: رفع الصور وتحليلها بـ Gemini Vision
- **Voice Recording**: تسجيل رسائل صوتية
- **Export Functionality**: تصدير المحادثات بصيغ TXT و PDF
- **Statistics Dashboard**: إحصائيات مفصلة مع رسوم بيانية

### الأمان والخصوصية
- **No Server Required**: يعمل بالكامل على المتصفح
- **Local Data**: جميع البيانات محفوظة محلياً
- **No Tracking**: لا يتم تتبع أو جمع أي معلومات شخصية

## المتطلبات

- متصفح ويب حديث يدعم:
  - ES6+ JavaScript
  - CSS Grid & Flexbox
  - Local Storage API
  - Fetch API (لـ Gemini API)

## استكشاف الأخطاء

### المشاكل الشائعة

1. **لا تعمل المحادثة**
   - تأكد من تفعيل JavaScript في المتصفح
   - تحقق من وجود أخطاء في Console (F12)

2. **لا يتم حفظ المحادثات**
   - تأكد من تفعيل Local Storage في المتصفح
   - تحقق من مساحة التخزين المتاحة

3. **مشاكل في Gemini API**
   - تأكد من صحة API Key
   - تحقق من اتصال الإنترنت
   - تأكد من تفعيل Gemini API في Google Cloud

### رسائل الخطأ

- **"خطأ في الاتصال"**: مشكلة في الشبكة أو API
- **"الشات غير موجود"**: تم حذف الشات أو خطأ في البيانات
- **"يرجى ملء جميع الحقول"**: حقول مطلوبة فارغة

## التطوير المستقبلي

### ميزات مقترحة
- 🌐 **استيراد** المحادثات من ملفات خارجية
- 🎨 **ثيمات متعددة** (فاتح/داكن/ملون)
- 🔍 **بحث متقدم** في الرسائل
- 📱 **تطبيق جوال** (PWA) للعمل دون اتصال
- 🌍 **ترجمة فورية** للرسائل
- 🎯 **محادثات جماعية** (Multi-bot conversations)
- 🔗 **مشاركة المحادثات** عبر روابط

### تحسينات تقنية
- **Service Worker** للعمل دون اتصال
- **IndexedDB** للتخزين المتقدم والأداء الأفضل
- **WebSocket** للمحادثة الفورية المتعددة
- **Web Speech API** للتعرف على الكلام وتحويله لنص
- **Video Generation** توليد فيديوهات قصيرة بالذكاء الاصطناعي

## الدعم

إذا واجهت أي مشاكل أو لديك اقتراحات، يمكنك:
- فتح issue في GitHub
- مراجعة الكود وإرسال Pull Request
- التواصل مع المطور

## الترخيص

هذا المشروع مفتوح المصدر ومتاح للاستخدام الشخصي والتجاري.

---

**ChatForge** - صنع بحب للمجتمع العربي 💙
