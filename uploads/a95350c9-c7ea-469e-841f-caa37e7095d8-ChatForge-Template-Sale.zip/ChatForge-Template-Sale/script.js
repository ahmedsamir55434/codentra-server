// ChatForge - الموقع الذكي لصناعة الشاتات المخصصة
// إعداد المتغيرات العامة
let currentChatId = null;
let chats = JSON.parse(localStorage.getItem('chats') || '[]');
let isTyping = false;
let attachedImages = [];
let isRecording = false;
let mediaRecorder = null;
let audioChunks = [];
let recordingStartTime = null;
let recordingTimer = null;
let suggestionsTimeout = null;
let currentSuggestions = [];
let voiceOutputEnabled = false;
let speechSynthesis = window.speechSynthesis;
let currentUtterance = null;

// عناصر DOM
const homePage = document.getElementById('home-page');
const chatPage = document.getElementById('chat-page');
const createModal = document.getElementById('create-chat-modal');
const editModal = document.getElementById('edit-chat-modal');
const chatsContainer = document.getElementById('chats-container');
const chatMessages = document.getElementById('chat-messages');
const messageInput = document.getElementById('message-input');
const sendButton = document.getElementById('send-button');
const typingIndicator = document.getElementById('typing-indicator');
const attachImageButton = document.getElementById('attach-image-button');
const imageInput = document.getElementById('image-input');
const imagePreviewContainer = document.getElementById('image-preview-container');
const voiceButton = document.getElementById('voice-button');
const voiceRecordingIndicator = document.getElementById('voice-recording-indicator');
const recordingTimeDisplay = document.getElementById('recording-time');
const exportModal = document.getElementById('export-modal');
const statsModal = document.getElementById('stats-modal');
const suggestionsContainer = document.getElementById('ai-suggestions-container');
const suggestionsList = document.getElementById('suggestions-list');

// تهيئة التطبيق
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
    loadChats();
    
    // تحميل الأصوات للقراءة الصوتية
    if (speechSynthesis) {
        speechSynthesis.getVoices();
        speechSynthesis.addEventListener('voiceschanged', () => {
            console.log('تم تحميل الأصوات:', speechSynthesis.getVoices().length);
        });
    }
});

// تهيئة التطبيق
function initializeApp() {
    showPage('home');
    updateChatsDisplay();
}

// إعداد مستمعي الأحداث
function setupEventListeners() {
    // أزرار الصفحة الرئيسية
    document.getElementById('create-new-chat-btn').addEventListener('click', showCreateModal);
    document.getElementById('back-to-home').addEventListener('click', () => showPage('home'));
    
    // نافذة إنشاء شات جديد
    document.getElementById('create-chat').addEventListener('click', createNewChat);
    document.getElementById('cancel-create').addEventListener('click', hideCreateModal);
    document.getElementById('close-modal').addEventListener('click', hideCreateModal);
    
    // نافذة تعديل الشات
    document.getElementById('save-chat').addEventListener('click', saveChatChanges);
    document.getElementById('cancel-edit').addEventListener('click', hideEditModal);
    document.getElementById('close-edit-modal').addEventListener('click', hideEditModal);
    document.getElementById('edit-chat-btn').addEventListener('click', showEditModal);
    document.getElementById('delete-chat-btn').addEventListener('click', deleteCurrentChat);
    
    // إرسال الرسائل
    sendButton.addEventListener('click', sendMessage);
    messageInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    
    // إغلاق النوافذ عند النقر خارجها
    createModal.addEventListener('click', function(e) {
        if (e.target === createModal) hideCreateModal();
    });
    
    editModal.addEventListener('click', function(e) {
        if (e.target === editModal) hideEditModal();
    });
    
    // تعديل حجم textarea تلقائياً
    messageInput.addEventListener('input', autoResizeTextarea);
    
    // الاقتراحات الذكية
    messageInput.addEventListener('input', handleInputForSuggestions);
    
    // إغلاق الاقتراحات
    document.getElementById('close-suggestions').addEventListener('click', hideSuggestions);
    
    // إرفاق الصور
    attachImageButton.addEventListener('click', () => imageInput.click());
    imageInput.addEventListener('change', handleImageSelection);
    
    // التسجيل الصوتي
    voiceButton.addEventListener('click', toggleVoiceRecording);
    
    // توليد الصور بالذكاء الاصطناعي
    const generateImageButton = document.getElementById('generate-image-button');
    if (generateImageButton) {
        generateImageButton.addEventListener('click', () => {
            if (window.ImageGeneration) {
                window.ImageGeneration.showImageGenerationModal();
            } else {
                console.error('وحدة توليد الصور غير محملة');
            }
        });
    }
    
    // استيراد المحادثات
    document.getElementById('import-chat-btn').addEventListener('click', () => {
        document.getElementById('import-file-input').click();
    });
    
    document.getElementById('import-file-input').addEventListener('change', handleImportFile);
    
    // أزرار التصدير والإحصائيات
    document.getElementById('export-chat-btn').addEventListener('click', showExportModal);
    document.getElementById('show-stats-btn').addEventListener('click', showStatsModal);
    
    // إغلاق نوافذ التصدير والإحصائيات
    document.getElementById('close-export-modal').addEventListener('click', () => exportModal.classList.remove('show'));
    document.getElementById('close-stats-modal').addEventListener('click', () => statsModal.classList.remove('show'));
    exportModal.addEventListener('click', (e) => {
        if (e.target === exportModal) exportModal.classList.remove('show');
    });
    statsModal.addEventListener('click', (e) => {
        if (e.target === statsModal) statsModal.classList.remove('show');
    });
    
    // أزرار التصدير
    document.getElementById('export-txt').addEventListener('click', exportAsTXT);
    document.getElementById('export-share').addEventListener('click', shareChat);
    
    // زر القراءة الصوتية
    document.getElementById('toggle-voice-btn').addEventListener('click', toggleVoiceOutput);
}

// عرض الصفحات
function showPage(page) {
    homePage.classList.remove('active');
    chatPage.classList.remove('active');
    
    if (page === 'home') {
        homePage.classList.add('active');
    } else if (page === 'chat') {
        chatPage.classList.add('active');
    }
}

// عرض نافذة إنشاء شات جديد
function showCreateModal() {
    createModal.classList.add('show');
    document.getElementById('chat-name-input').value = '';
    document.getElementById('chat-description-input').value = '';
}

// إخفاء نافذة إنشاء شات جديد
function hideCreateModal() {
    createModal.classList.remove('show');
}

// عرض نافذة تعديل الشات
function showEditModal() {
    if (!currentChatId) return;
    
    const chat = chats.find(c => c.id === currentChatId);
    if (!chat) return;
    
    document.getElementById('edit-chat-name-input').value = chat.name;
    document.getElementById('edit-chat-description-input').value = chat.description;
    editModal.classList.add('show');
}

// إخفاء نافذة تعديل الشات
function hideEditModal() {
    editModal.classList.remove('show');
}

// إنشاء شات جديد
function createNewChat() {
    const name = document.getElementById('chat-name-input').value.trim();
    const description = document.getElementById('chat-description-input').value.trim();
    
    if (!name || !description) {
        alert('يرجى ملء جميع الحقول المطلوبة');
        return;
    }
    
    const newChat = {
        id: generateId(),
        name: name,
        description: description,
        messages: [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
    
    chats.push(newChat);
    saveChats();
    hideCreateModal();
    openChat(newChat.id);
}

// حفظ تغييرات الشات
function saveChatChanges() {
    if (!currentChatId) return;
    
    const name = document.getElementById('edit-chat-name-input').value.trim();
    const description = document.getElementById('edit-chat-description-input').value.trim();
    
    if (!name || !description) {
        alert('يرجى ملء جميع الحقول المطلوبة');
        return;
    }
    
    const chatIndex = chats.findIndex(c => c.id === currentChatId);
    if (chatIndex !== -1) {
        chats[chatIndex].name = name;
        chats[chatIndex].description = description;
        chats[chatIndex].updatedAt = new Date().toISOString();
        
        saveChats();
        hideEditModal();
        updateChatDisplay();
        loadChats(); // تحديث عرض الشاتات في الصفحة الرئيسية
    }
}

// حذف الشات الحالي
function deleteCurrentChat() {
    if (!currentChatId) return;
    
    if (confirm('هل أنت متأكد من حذف هذا الشات؟ لا يمكن التراجع عن هذا الإجراء.')) {
        chats = chats.filter(c => c.id !== currentChatId);
        saveChats();
        currentChatId = null;
        showPage('home');
        loadChats();
    }
}

// فتح شات محدد
function openChat(chatId) {
    const chat = chats.find(c => c.id === chatId);
    if (!chat) return;
    
    currentChatId = chatId;
    updateChatDisplay();
    loadMessages();
    showPage('chat');
    
    // التركيز على حقل الإدخال
    setTimeout(() => messageInput.focus(), 100);
}

// حذف شات محدد
function deleteChat(chatId, event) {
    event.stopPropagation();
    
    if (confirm('هل أنت متأكد من حذف هذا الشات؟')) {
        chats = chats.filter(c => c.id !== chatId);
        saveChats();
        loadChats();
        
        if (currentChatId === chatId) {
            showPage('home');
            currentChatId = null;
        }
    }
}

// تحديث عرض معلومات الشات الحالي
function updateChatDisplay() {
    if (!currentChatId) return;
    
    const chat = chats.find(c => c.id === currentChatId);
    if (!chat) return;
    
    document.getElementById('chat-name').textContent = chat.name;
    document.getElementById('chat-description').textContent = chat.description;
}

// تحميل الرسائل في الشات الحالي
function loadMessages() {
    if (!currentChatId) return;
    
    const chat = chats.find(c => c.id === currentChatId);
    if (!chat) return;
    
    chatMessages.innerHTML = '';
    
    if (chat.messages.length === 0) {
        chatMessages.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">💬</div>
                <div class="empty-state-text">ابدأ محادثة جديدة</div>
                <div class="empty-state-subtext">اكتب رسالتك الأولى أدناه</div>
            </div>
        `;
        return;
    }
    
    chat.messages.forEach(message => {
        addMessageToUI(message.content, message.sender, message.timestamp, message.images);
    });
    
    // التمرير لأسفل
    scrollToBottom();
}

// إرسال رسالة
async function sendMessage() {
    const message = messageInput.value.trim();
    if ((!message && attachedImages.length === 0) || isTyping) return;
    
    // إضافة رسالة المستخدم
    const userMessage = {
        content: message || 'أرسل صورة',
        sender: 'user',
        timestamp: new Date().toISOString(),
        images: attachedImages.length > 0 ? [...attachedImages] : undefined
    };
    
    addMessageToUI(message || 'أرسل صورة', 'user', userMessage.timestamp, userMessage.images);
    addMessageToChat(userMessage);
    
    // حفظ الصور المرفقة للاستخدام مع API
    const messagImages = [...attachedImages];
    
    // مسح حقل الإدخال والصور
    messageInput.value = '';
    attachedImages = [];
    updateImagePreview();
    autoResizeTextarea();
    
    // إظهار مؤشر الكتابة
    showTypingIndicator();
    
    try {
        // الحصول على رد من Gemini API
        const aiResponse = await getGeminiResponse(message, messagImages);
        
        // إخفاء مؤشر الكتابة
        hideTypingIndicator();
        
        // إضافة رد الذكاء الصناعي
        const aiMessage = {
            content: aiResponse,
            sender: 'ai',
            timestamp: new Date().toISOString()
        };
        
        addMessageToUI(aiResponse, 'ai', aiMessage.timestamp);
        addMessageToChat(aiMessage);
        
    } catch (error) {
        console.error('خطأ في الحصول على الرد:', error);
        hideTypingIndicator();
        
        // إضافة رسالة خطأ واضحة
        let errorContent = 'عذراً، حدث خطأ في الاتصال بـ Gemini API.';
        
        if (error.message && error.message.includes('API')) {
            errorContent = error.message;
        } else if (error.message && error.message.includes('fetch')) {
            errorContent = '❌ خطأ في الاتصال بالإنترنت. يرجى التحقق من اتصالك.';
        } else if (error.message) {
            errorContent = `❌ خطأ: ${error.message}`;
        }
        
        const errorMessage = {
            content: errorContent + '\n\n💡 تأكد من:\n- مفتاح API صحيح\n- الاتصال بالإنترنت متوفر',
            sender: 'ai',
            timestamp: new Date().toISOString()
        };
        
        addMessageToUI(errorMessage.content, 'ai', errorMessage.timestamp);
        addMessageToChat(errorMessage);
    }
}

// الحصول على رد من Gemini API
async function getGeminiResponse(message, images = []) {
    // استخدام دالة Gemini المحسنة من الملف المنفصل
    if (window.GeminiIntegration && window.GeminiIntegration.getGeminiResponse) {
        return await window.GeminiIntegration.getGeminiResponse(message, images);
    }
    
    // في حالة عدم توفر Gemini Integration
    throw new Error('⚠️ خطأ: لم يتم تحميل Gemini Integration بشكل صحيح');
}

// إضافة رسالة إلى واجهة المستخدم
function addMessageToUI(content, sender, timestamp, images = []) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}`;
    messageDiv.dataset.timestamp = timestamp;
    messageDiv.dataset.sender = sender;
    messageDiv.dataset.content = content;
    
    // تحديد اسم المرسل
    const senderName = sender === 'user' ? 'أنت' : 'المساعد الذكي';
    const senderIcon = sender === 'user' ? '👤' : '🤖';
    
    let imagesHTML = '';
    if (images && images.length > 0) {
        imagesHTML = images.map(img => 
            `<img src="${img}" class="message-image" onclick="showImageModal('${img}')" alt="صورة مرفقة" />`
        ).join('');
    }
    
    // التحقق من حالة المفضلة
    const messageId = `${currentChatId}-${timestamp}`;
    const isFavorited = isMessageFavorited(messageId);
    
    messageDiv.innerHTML = `
        <button class="favorite-btn ${isFavorited ? 'favorited' : ''}" onclick="toggleFavorite(this)" data-message-id="${messageId}">
            <svg viewBox="0 0 24 24">
                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
            </svg>
        </button>
        <div class="message-header">
            <span class="message-sender">${senderIcon} ${senderName}</span>
        </div>
        ${imagesHTML}
        <div class="message-content">${content}</div>
    `;
    
    chatMessages.appendChild(messageDiv);
    
    // إضافة زر القراءة الصوتية لرسائل AI
    if (sender === 'ai') {
        addVoiceButtonToMessage(messageDiv, content);
    }
    
    scrollToBottom();
}

// إضافة رسالة إلى بيانات الشات
function addMessageToChat(message) {
    if (!currentChatId) return;
    
    const chatIndex = chats.findIndex(c => c.id === currentChatId);
    if (chatIndex !== -1) {
        chats[chatIndex].messages.push(message);
        chats[chatIndex].updatedAt = new Date().toISOString();
        saveChats();
    }
}

// إظهار مؤشر الكتابة
function showTypingIndicator() {
    isTyping = true;
    typingIndicator.classList.add('show');
    sendButton.disabled = true;
    scrollToBottom();
}

// إخفاء مؤشر الكتابة
function hideTypingIndicator() {
    isTyping = false;
    typingIndicator.classList.remove('show');
    sendButton.disabled = false;
}

// التمرير لأسفل منطقة الرسائل
function scrollToBottom() {
    setTimeout(() => {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }, 100);
}

// تعديل حجم textarea تلقائياً
function autoResizeTextarea() {
    messageInput.style.height = 'auto';
    messageInput.style.height = Math.min(messageInput.scrollHeight, 120) + 'px';
}

// تحميل وعرض الشاتات
function loadChats() {
    updateChatsDisplay();
}

// تحديث عرض الشاتات
function updateChatsDisplay() {
    chatsContainer.innerHTML = '';
    
    if (chats.length === 0) {
        chatsContainer.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">💭</div>
                <div class="empty-state-text">لا توجد محادثات بعد</div>
                <div class="empty-state-subtext">ابدأ بإنشاء شات جديد لتجربة الميزات</div>
            </div>
        `;
        return;
    }
    
    // ترتيب الشاتات حسب آخر تحديث
    const sortedChats = chats.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
    
    sortedChats.forEach(chat => {
        const chatCard = document.createElement('div');
        chatCard.className = 'chat-card';
        chatCard.onclick = () => openChat(chat.id);
        
        const lastMessage = chat.messages.length > 0 
            ? chat.messages[chat.messages.length - 1].content
            : 'لا توجد رسائل بعد';
        
        const lastMessagePreview = lastMessage.length > 50 
            ? lastMessage.substring(0, 50) + '...'
            : lastMessage;
        
        chatCard.innerHTML = `
            <div class="chat-card-title">${chat.name}</div>
            <div class="chat-card-description">${chat.description}</div>
            <div class="chat-card-last-message">${lastMessagePreview}</div>
            <div class="chat-card-actions">
                <button class="chat-card-button" onclick="event.stopPropagation(); openChat('${chat.id}')">استمرار</button>
                <button class="chat-card-button delete" onclick="deleteChat('${chat.id}', event)">حذف</button>
            </div>
        `;
        
        chatsContainer.appendChild(chatCard);
    });
}

// حفظ الشاتات في localStorage
function saveChats() {
    localStorage.setItem('chats', JSON.stringify(chats));
}

// توليد معرف فريد
function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

// وظائف مساعدة إضافية
function formatDate(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) {
        return 'أمس';
    } else if (diffDays < 7) {
        return `منذ ${diffDays} أيام`;
    } else {
        return date.toLocaleDateString('ar-SA');
    }
}

// تصدير الشاتات (للاستخدام المستقبلي)
function exportChats() {
    const dataStr = JSON.stringify(chats, null, 2);
    const dataBlob = new Blob([dataStr], {type: 'application/json'});
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'chats-backup.json';
    link.click();
    URL.revokeObjectURL(url);
}

// استيراد الشاتات (للاستخدام المستقبلي)
function importChats(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const importedChats = JSON.parse(e.target.result);
            if (Array.isArray(importedChats)) {
                chats = importedChats;
                saveChats();
                loadChats();
                alert('تم استيراد الشاتات بنجاح!');
            } else {
                alert('ملف غير صالح');
            }
        } catch (error) {
            alert('خطأ في قراءة الملف');
        }
    };
    reader.readAsText(file);
}

// معالجة اختيار الصور
function handleImageSelection(event) {
    const files = Array.from(event.target.files);
    
    files.forEach(file => {
        if (!file.type.startsWith('image/')) {
            alert('يرجى اختيار ملفات صور فقط');
            return;
        }
        
        // التحقق من حجم الصورة (أقصى حجم 5MB)
        if (file.size > 5 * 1024 * 1024) {
            alert('حجم الصورة كبير جداً. الحد الأقصى 5MB');
            return;
        }
        
        const reader = new FileReader();
        reader.onload = function(e) {
            attachedImages.push(e.target.result);
            updateImagePreview();
        };
        reader.readAsDataURL(file);
    });
    
    // إعادة تعيين input لتمكين اختيار نفس الملف مرة أخرى
    event.target.value = '';
}

// تحديث عرض معاينة الصور
function updateImagePreview() {
    imagePreviewContainer.innerHTML = '';
    
    if (attachedImages.length === 0) {
        imagePreviewContainer.classList.remove('has-images');
        return;
    }
    
    imagePreviewContainer.classList.add('has-images');
    
    attachedImages.forEach((image, index) => {
        const previewItem = document.createElement('div');
        previewItem.className = 'image-preview-item';
        
        previewItem.innerHTML = `
            <img src="${image}" alt="معاينة ${index + 1}" />
            <button class="image-preview-remove" onclick="removeAttachedImage(${index})" title="حذف الصورة">×</button>
        `;
        
        imagePreviewContainer.appendChild(previewItem);
    });
}

// حذف صورة مرفقة
function removeAttachedImage(index) {
    attachedImages.splice(index, 1);
    updateImagePreview();
}

// عرض الصورة في نافذة منبثقة
function showImageModal(imageSrc) {
    const modal = document.createElement('div');
    modal.className = 'image-modal show';
    modal.innerHTML = `<img src="${imageSrc}" alt="عرض الصورة" />`;
    modal.onclick = () => modal.remove();
    document.body.appendChild(modal);
}

// إضافة بعض الشاتات التجريبية عند التحميل الأول
if (chats.length === 0) {
    const sampleChats = [
        {
            id: generateId(),
            name: 'المساعد البرمجي',
            description: 'ساعدني في كتابة أكواد جافاسكربت بطريقة احترافية وتقديم نصائح لتطوير الويب.',
            messages: [
                {
                    content: 'مرحباً! أنا هنا لمساعدتك في البرمجة. كيف يمكنني مساعدتك اليوم؟',
                    sender: 'ai',
                    timestamp: new Date(Date.now() - 300000).toISOString()
                },
                {
                    content: 'أريد تعلم JavaScript بشكل أفضل',
                    sender: 'user',
                    timestamp: new Date(Date.now() - 240000).toISOString()
                },
                {
                    content: 'ممتاز! JavaScript لغة رائعة. سأبدأ بتعليمك الأساسيات والمفاهيم المتقدمة.',
                    sender: 'ai',
                    timestamp: new Date(Date.now() - 180000).toISOString()
                }
            ],
            createdAt: new Date(Date.now() - 3600000).toISOString(),
            updatedAt: new Date(Date.now() - 180000).toISOString()
        },
        {
            id: generateId(),
            name: 'المعلم الرياضي',
            description: 'أشرح لك الرياضيات بطريقة بسيطة ومفهومة، من الجبر إلى التفاضل والتكامل.',
            messages: [
                {
                    content: 'مرحباً! أنا معلمك في الرياضيات. ما هو الموضوع الذي تريد أن نبدأ به؟',
                    sender: 'ai',
                    timestamp: new Date(Date.now() - 600000).toISOString()
                }
            ],
            createdAt: new Date(Date.now() - 7200000).toISOString(),
            updatedAt: new Date(Date.now() - 600000).toISOString()
        }
    ];
    
    chats = sampleChats;
    saveChats();
}

// ===================
// وظائف التسجيل الصوتي
// ===================

async function toggleVoiceRecording() {
    if (!isRecording) {
        await startVoiceRecording();
    } else {
        await stopVoiceRecording();
    }
}

async function startVoiceRecording() {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaRecorder = new MediaRecorder(stream);
        audioChunks = [];
        
        mediaRecorder.ondataavailable = (event) => {
            audioChunks.push(event.data);
        };
        
        mediaRecorder.onstop = async () => {
            const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
            await processVoiceRecording(audioBlob);
            stream.getTracks().forEach(track => track.stop());
        };
        
        mediaRecorder.start();
        isRecording = true;
        recordingStartTime = Date.now();
        
        // إظهار مؤشر التسجيل
        voiceRecordingIndicator.classList.add('active');
        voiceButton.classList.add('recording');
        
        // بدء عداد الوقت
        updateRecordingTime();
        recordingTimer = setInterval(updateRecordingTime, 1000);
        
        console.log('🎤 بدء التسجيل الصوتي');
    } catch (error) {
        console.error('خطأ في الوصول للميكروفون:', error);
        alert('لا يمكن الوصول للميكروفون. يرجى السماح بالوصول.');
    }
}

async function stopVoiceRecording() {
    if (mediaRecorder && isRecording) {
        mediaRecorder.stop();
        isRecording = false;
        
        // إخفاء مؤشر التسجيل
        voiceRecordingIndicator.classList.remove('active');
        voiceButton.classList.remove('recording');
        
        // إيقاف عداد الوقت
        clearInterval(recordingTimer);
        recordingTimeDisplay.textContent = '00:00';
        
        console.log('⏹️ إيقاف التسجيل الصوتي');
    }
}

function updateRecordingTime() {
    if (!recordingStartTime) return;
    
    const elapsed = Math.floor((Date.now() - recordingStartTime) / 1000);
    const minutes = Math.floor(elapsed / 60);
    const seconds = elapsed % 60;
    
    recordingTimeDisplay.textContent = 
        `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

async function processVoiceRecording(audioBlob) {
    try {
        // تحويل الصوت إلى نص باستخدام Web Speech API
        const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
        recognition.lang = 'ar-SA';
        recognition.continuous = false;
        
        // للأسف Web Speech API لا يدعم معالجة blob مباشرة
        // سنضيف النص مباشرة أو نرسل الصوت للـ AI
        
        // بديل: إضافة رسالة صوتية
        const reader = new FileReader();
        reader.onload = async function(e) {
            const audioDataUrl = e.target.result;
            
            // إضافة رسالة بالصوت
            const userMessage = {
                content: '🎤 رسالة صوتية',
                sender: 'user',
                timestamp: new Date().toISOString(),
                audio: audioDataUrl
            };
            
            addMessageToUI('🎤 رسالة صوتية', 'user', userMessage.timestamp);
            addMessageToChat(userMessage);
            
            // إظهار مؤشر الكتابة
            showTypingIndicator();
            
            // الحصول على رد من AI
            try {
                const aiResponse = await getGeminiResponse('المستخدم أرسل رسالة صوتية. يرجى الرد بشكل مناسب.');
                hideTypingIndicator();
                
                const aiMessage = {
                    content: aiResponse,
                    sender: 'ai',
                    timestamp: new Date().toISOString()
                };
                
                addMessageToUI(aiResponse, 'ai', aiMessage.timestamp);
                addMessageToChat(aiMessage);
            } catch (error) {
                console.error('خطأ في الحصول على الرد:', error);
                hideTypingIndicator();
                
                const errorMessage = {
                    content: '❌ عذراً، لم أتمكن من معالجة الرسالة الصوتية. يرجى المحاولة مرة أخرى.',
                    sender: 'ai',
                    timestamp: new Date().toISOString()
                };
                
                addMessageToUI(errorMessage.content, 'ai', errorMessage.timestamp);
                addMessageToChat(errorMessage);
            }
        };
        
        reader.readAsDataURL(audioBlob);
        
    } catch (error) {
        console.error('خطأ في معالجة التسجيل:', error);
        alert('حدث خطأ في معالجة التسجيل الصوتي');
    }
}

// ===================
// وظائف التصدير
// ===================

function showExportModal() {
    if (!currentChatId) {
        alert('يرجى فتح محادثة أولاً');
        return;
    }
    exportModal.classList.add('show');
}

function exportAsTXT() {
    const chat = chats.find(c => c.id === currentChatId);
    if (!chat) return;
    
    let content = `${chat.name}\n`;
    content += `${'='.repeat(chat.name.length)}\n\n`;
    content += `الوصف: ${chat.description}\n`;
    content += `تاريخ الإنشاء: ${new Date(chat.createdAt).toLocaleString('ar-SA')}\n\n`;
    content += `${'='.repeat(50)}\n\n`;
    
    chat.messages.forEach(msg => {
        const sender = msg.sender === 'user' ? 'أنت' : chat.name;
        const time = new Date(msg.timestamp).toLocaleTimeString('ar-SA');
        content += `[${time}] ${sender}:\n${msg.content}\n\n`;
    });
    
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${chat.name} - ${new Date().toLocaleDateString('ar-SA')}.txt`;
    link.click();
    URL.revokeObjectURL(url);
    
    exportModal.classList.remove('show');
    alert('✅ تم تصدير المحادثة كملف نصي!');
}

// تم إزالة ميزة تصدير PDF

function shareChat() {
    const chat = chats.find(c => c.id === currentChatId);
    if (!chat) return;
    
    const shareData = {
        title: chat.name,
        text: `محادثة: ${chat.name}\n${chat.description}\n\nعدد الرسائل: ${chat.messages.length}`,
    };
    
    if (navigator.share) {
        navigator.share(shareData)
            .then(() => {
                exportModal.classList.remove('show');
                console.log('تمت المشاركة بنجاح');
            })
            .catch((error) => console.log('خطأ في المشاركة:', error));
    } else {
        // نسخ للحافظة
        const text = `${shareData.title}\n\n${shareData.text}`;
        navigator.clipboard.writeText(text).then(() => {
            exportModal.classList.remove('show');
            alert('✅ تم نسخ معلومات المحادثة للحافظة!');
        });
    }
}

// ===================
// استيراد المحادثات
// ===================

async function handleImportFile(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    // التحقق من نوع الملف
    if (!file.name.endsWith('.txt')) {
        alert('⚠️ يرجى اختيار ملف TXT فقط');
        return;
    }
    
    try {
        const text = await file.text();
        
        console.log('📂 اسم الملف:', file.name);
        console.log('📏 حجم الملف:', file.size, 'بايت');
        console.log('📝 أول 200 حرف من الملف:', text.substring(0, 200));
        
        const importedChat = parseImportedChat(text);
        
        if (!importedChat) {
            alert('❌ لا يمكن قراءة الملف\n\n' +
                  '💡 تأكد من:\n' +
                  '1️⃣ الملف بصيغة TXT\n' +
                  '2️⃣ الملف يحتوي على نص\n' +
                  '3️⃣ الملف غير تالف\n\n' +
                  '🔍 افتح Console (F12) لمزيد من التفاصيل\n\n' +
                  '💪 يمكنك استيراد أي ملف نصي - ليس بالضرورة من ChatForge!');
            return;
        }
        
        // إنشاء محادثة جديدة من البيانات المستوردة
        const newChat = {
            id: Date.now(),
            name: importedChat.name + ' (مستورد)',
            description: importedChat.description,
            createdAt: importedChat.originalCreatedAt || new Date().toISOString(),
            messages: importedChat.messages
        };
        
        chats.push(newChat);
        saveChats();
        updateChatsDisplay();
        
        // عرض المحادثة المستوردة
        openChat(newChat.id);
        
        alert(`✅ تم استيراد المحادثة بنجاح!\n\n📝 ${newChat.name}\n💬 ${newChat.messages.length} رسالة`);
        
        console.log('✅ تم استيراد المحادثة:', newChat);
        
    } catch (error) {
        console.error('❌ خطأ في استيراد الملف:', error);
        console.error('📋 تفاصيل الخطأ:', {
            message: error.message,
            stack: error.stack,
            name: error.name
        });
        
        let errorMessage = '❌ حدث خطأ أثناء استيراد الملف\n\n';
        
        // تحديد نوع الخطأ
        if (error.name === 'TypeError') {
            errorMessage += '⚠️ خطأ في قراءة الملف\n';
            errorMessage += 'تأكد من أن الملف صالح وغير تالف';
        } else if (error.name === 'SyntaxError') {
            errorMessage += '⚠️ خطأ في تنسيق الملف\n';
            errorMessage += 'تأكد من أن الملف TXT صحيح';
        } else if (error.message.includes('Cannot read')) {
            errorMessage += '⚠️ الملف فارغ أو لا يمكن قراءته\n';
            errorMessage += 'حاول ملف آخر';
        } else {
            errorMessage += `⚠️ ${error.message}\n`;
            errorMessage += '\n🔍 افتح Console (F12) لمزيد من التفاصيل';
        }
        
        alert(errorMessage);
    } finally {
        // إعادة تعيين input
        event.target.value = '';
    }
}

function parseImportedChat(text) {
    try {
        // التحقق من النص
        if (!text || typeof text !== 'string') {
            console.error('❌ النص غير صالح');
            return null;
        }
        
        if (text.trim().length === 0) {
            console.error('❌ الملف فارغ');
            return null;
        }
        
        const lines = text.split('\n').filter(line => line.trim());
        let chatName = 'محادثة مستوردة';
        let chatDescription = 'تم استيراد هذه المحادثة من ملف خارجي';
        const messages = [];
        
        console.log('🔍 بدء تحليل الملف...');
        console.log('📄 عدد الأسطر:', lines.length);
        console.log('📏 طول النص:', text.length);
        console.log('🌟 وضع الاستيراد: مرن (يقبل أي تنسيق)');
        
        // محاولة 1: استخراج اسم المحادثة بطرق متعددة
        let nameMatch = text.match(/اسم المحادثة:\s*(.+)/);
        if (nameMatch) {
            chatName = nameMatch[1].trim();
        } else {
            // محاولة استخراج من السطر الأول إذا كان يحتوي على "محادثة:"
            nameMatch = text.match(/محادثة:\s*(.+)/);
            if (nameMatch) {
                chatName = nameMatch[1].trim();
            } else {
                // استخدام أول سطر غير فارغ كاسم
                chatName = lines[0] ? lines[0].replace(/[📝🔥✨💬]/g, '').trim() : 'محادثة مستوردة';
            }
        }
        
        console.log('📝 اسم المحادثة:', chatName);
        
        // محاولة 2: استخراج الوصف
        const descMatch = text.match(/الوصف:\s*(.+)/);
        if (descMatch) {
            chatDescription = descMatch[1].trim();
        }
        
        console.log('📋 الوصف:', chatDescription || 'لا يوجد');
        
        // محاولة 3: استخراج تاريخ الإنشاء الأصلي
        let originalCreatedAt = null;
        const dateMatch = text.match(/تاريخ الإنشاء:\s*(.+)/);
        if (dateMatch) {
            const dateStr = dateMatch[1].trim();
            console.log('📅 تاريخ الإنشاء الأصلي:', dateStr);
            // محاولة تحويله لتاريخ صحيح
            try {
                const parsedDate = new Date(dateStr);
                if (!isNaN(parsedDate.getTime())) {
                    originalCreatedAt = parsedDate.toISOString();
                }
            } catch (e) {
                // إذا فشل التحويل، سنستخدم التاريخ الحالي
            }
        }
        
        // محاولة 3: استخراج الرسائل بطرق متعددة
        let messagesText = '';
        
        // طريقة 1: البحث عن "الرسائل:"
        if (text.includes('الرسائل:')) {
            messagesText = text.split('الرسائل:')[1];
        } 
        // طريقة 2: البحث عن خط الفصل
        else if (text.includes('════')) {
            const parts = text.split('════');
            messagesText = parts[parts.length - 1];
        }
        // طريقة 3: استخدام كل النص إذا كان يحتوي على رسائل
        else {
            messagesText = text;
        }
        
        console.log('💬 طول قسم الرسائل:', messagesText.length);
        
        // تحليل الرسائل بطرق متعددة
        
        // طريقة 1: تقسيم حسب النمط [XX:XX]
        const messagePattern = /\[(\d{1,2}:\d{2})\]\s*(.+?):\s*/g;
        const messageBlocks = messagesText.split(messagePattern).filter(s => s.trim());
        
        console.log('📦 عدد الأجزاء المقسمة:', messageBlocks.length);
        
        if (messageBlocks.length > 3) {
            // تحليل الأجزاء (كل 3 عناصر = رسالة واحدة: time, sender, content)
            for (let i = 0; i < messageBlocks.length; i += 3) {
                if (i + 2 < messageBlocks.length) {
                    try {
                        const time = messageBlocks[i];
                        const sender = messageBlocks[i + 1];
                        const content = messageBlocks[i + 2];
                        
                        if (content && content.trim()) {
                            // تحويل الوقت الأصلي إلى timestamp
                            let timestamp = new Date().toISOString();
                            if (time && time.match(/\d{1,2}:\d{2}/)) {
                                const [hours, minutes] = time.split(':');
                                const messageDate = new Date();
                                messageDate.setHours(parseInt(hours), parseInt(minutes), 0, 0);
                                timestamp = messageDate.toISOString();
                            }
                            
                            messages.push({
                                id: Date.now() + Math.random(),
                                sender: (sender && (sender.includes('أنت') || sender.includes('You'))) ? 'user' : 'ai',
                                content: content.trim(),
                                timestamp: timestamp,
                                images: [],
                                originalTime: time // حفظ الوقت الأصلي
                            });
                        }
                    } catch (matchError) {
                        console.warn('⚠️ تخطي رسالة بسبب خطأ:', matchError);
                        continue;
                    }
                }
            }
            console.log('✅ استخدام النمط 1 - عدد الرسائل:', messages.length);
        } else {
            // طريقة 2: نمط أبسط - سطر بسطر بدون دمج
            console.log('🔄 استخدام النمط 2 - تحليل سطر بسطر');
            const messageLines = messagesText.split('\n').filter(l => l.trim());
            
            for (let i = 0; i < messageLines.length; i++) {
                const line = messageLines[i];
                
                // تخطي الأسطر الفارغة أو القصيرة جداً
                if (line.trim().length < 3) continue;
                
                // البحث عن سطر يبدأ برسالة
                if (line.match(/\[?\d{1,2}:\d{2}\]?/) || line.includes(':')) {
                    let sender = 'ai';
                    let content = line;
                    let originalTime = null;
                    
                    // استخراج الوقت الأصلي إذا كان موجوداً
                    const timeMatch = line.match(/\[?(\d{1,2}:\d{2})\]?/);
                    if (timeMatch) {
                        originalTime = timeMatch[1];
                    }
                    
                    // محاولة فصل المرسل عن المحتوى
                    const colonIndex = line.indexOf(':');
                    if (colonIndex > 0 && colonIndex < 50) { // التأكد من أن : قريبة من البداية
                        const beforeColon = line.substring(0, colonIndex);
                        const afterColon = line.substring(colonIndex + 1);
                        
                        if (beforeColon.includes('أنت') || beforeColon.includes('You') || 
                            beforeColon.includes('user') || beforeColon.includes('USER')) {
                            sender = 'user';
                        }
                        
                        content = afterColon.trim();
                    }
                    
                    // إزالة الوقت من المحتوى إذا كان موجوداً
                    content = content.replace(/^\[?\d{1,2}:\d{2}\]?\s*/g, '').trim();
                    
                    if (content && content.length > 0) {
                        // تحويل الوقت الأصلي إلى timestamp
                        let timestamp = new Date().toISOString();
                        if (originalTime) {
                            const [hours, minutes] = originalTime.split(':');
                            const messageDate = new Date();
                            messageDate.setHours(parseInt(hours), parseInt(minutes), 0, 0);
                            timestamp = messageDate.toISOString();
                        }
                        
                        messages.push({
                            id: Date.now() + Math.random(),
                            sender: sender,
                            content: content,
                            timestamp: timestamp,
                            images: [],
                            originalTime: originalTime
                        });
                    }
                }
            }
        }
        
        console.log('📊 عدد الرسائل المستخرجة:', messages.length);
        
        // التحقق من النتيجة
        if (!chatName) {
            chatName = 'محادثة مستوردة';
        }
        
        // إذا لم يتم العثور على رسائل بالتنسيق القياسي
        // قم بتحويل النص إلى رسائل بناءً على الفقرات
        if (messages.length === 0) {
            console.log('⚠️ لم يتم العثور على رسائل بالتنسيق القياسي');
            console.log('🔄 محاولة تحويل النص الكامل إلى رسائل...');
            
            // تقسيم النص إلى فقرات (سطرين متتاليين فارغين أو أكثر)
            const paragraphs = text.split(/\n\s*\n/).filter(p => p.trim());
            
            if (paragraphs.length > 0) {
                console.log('📝 عدد الفقرات المكتشفة:', paragraphs.length);
                
                // تحويل كل فقرة إلى رسالة
                paragraphs.forEach((paragraph, index) => {
                    const cleanParagraph = paragraph.trim();
                    if (cleanParagraph.length > 0) {
                        // تناوب بين user و ai
                        messages.push({
                            id: Date.now() + Math.random(),
                            sender: index % 2 === 0 ? 'user' : 'ai',
                            content: cleanParagraph,
                            timestamp: new Date().toISOString(),
                            images: []
                        });
                    }
                });
            } else {
                // إذا لم توجد فقرات، استخدم كل النص كرسالة واحدة
                console.log('📄 تحويل النص الكامل إلى رسالة واحدة');
                messages.push({
                    id: Date.now(),
                    sender: 'user',
                    content: text.trim(),
                    timestamp: new Date().toISOString(),
                    images: []
                });
            }
            
            console.log('✅ تم إنشاء', messages.length, 'رسالة من النص');
        }
        
        // التحقق النهائي
        if (messages.length === 0) {
            console.error('❌ فشل في إنشاء أي رسائل');
            return null;
        }
        
        console.log('✅ تم التحليل بنجاح!');
        console.log('📋 النتيجة:', {
            اسم: chatName,
            وصف: chatDescription,
            'عدد الرسائل': messages.length
        });
        
        return {
            name: chatName,
            description: chatDescription || 'محادثة مستوردة',
            messages: messages,
            originalCreatedAt: originalCreatedAt // تاريخ الإنشاء الأصلي
        };
        
    } catch (error) {
        console.error('❌ خطأ في تحليل الملف:', error);
        return null;
    }
}

// ===================
// وظائف الإحصائيات
// ===================

function showStatsModal() {
    calculateAndDisplayStats();
    statsModal.classList.add('show');
}

function calculateAndDisplayStats() {
    // حساب الإحصائيات
    const totalChats = chats.length;
    const totalMessages = chats.reduce((sum, chat) => sum + chat.messages.length, 0);
    
    // إيجاد الشات الأكثر استخداماً
    let mostUsedChat = '-';
    if (chats.length > 0) {
        const chatWithMostMessages = chats.reduce((max, chat) => 
            chat.messages.length > max.messages.length ? chat : max
        );
        mostUsedChat = chatWithMostMessages.name;
    }
    
    // حساب أيام النشاط
    const uniqueDates = new Set();
    chats.forEach(chat => {
        chat.messages.forEach(msg => {
            const date = new Date(msg.timestamp).toDateString();
            uniqueDates.add(date);
        });
    });
    const activeDays = uniqueDates.size;
    
    // عرض الإحصائيات
    document.getElementById('total-messages').textContent = totalMessages;
    document.getElementById('total-chats').textContent = totalChats;
    document.getElementById('most-used-chat').textContent = mostUsedChat;
    document.getElementById('active-days').textContent = activeDays;
    
    // رسم الرسوم البيانية
    drawActivityChart();
    drawMessageDistributionChart();
}

function drawActivityChart() {
    const canvas = document.getElementById('chat-activity-chart');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    
    // إنشاء بيانات آخر 7 أيام
    const last7Days = [];
    const messageCounts = [];
    
    for (let i = 6; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        const dateStr = date.toLocaleDateString('ar-SA', { weekday: 'short' });
        last7Days.push(dateStr);
        
        // حساب عدد الرسائل في هذا اليوم
        let count = 0;
        chats.forEach(chat => {
            chat.messages.forEach(msg => {
                const msgDate = new Date(msg.timestamp);
                if (msgDate.toDateString() === date.toDateString()) {
                    count++;
                }
            });
        });
        messageCounts.push(count);
    }
    
    // رسم الرسم البياني
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: last7Days,
            datasets: [{
                label: 'عدد الرسائل',
                data: messageCounts,
                borderColor: '#00d4ff',
                backgroundColor: 'rgba(0, 212, 255, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    labels: { color: '#ffffff' }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { color: '#ffffff' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: {
                    ticks: { color: '#ffffff' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

function drawMessageDistributionChart() {
    const canvas = document.getElementById('message-distribution-chart');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    
    // بيانات توزيع الرسائل حسب الشات
    const chatNames = chats.slice(0, 5).map(c => c.name);
    const messageCounts = chats.slice(0, 5).map(c => c.messages.length);
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: chatNames,
            datasets: [{
                label: 'عدد الرسائل',
                data: messageCounts,
                backgroundColor: [
                    'rgba(0, 212, 255, 0.8)',
                    'rgba(118, 75, 162, 0.8)',
                    'rgba(255, 0, 255, 0.8)',
                    'rgba(0, 255, 153, 0.8)',
                    'rgba(255, 153, 0, 0.8)'
                ],
                borderColor: [
                    '#00d4ff',
                    '#764ba2',
                    '#ff00ff',
                    '#00ff99',
                    '#ff9900'
                ],
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    labels: { color: '#ffffff' }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { color: '#ffffff' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: {
                    ticks: { color: '#ffffff' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// دالة لإضافة صورة مولدة بالذكاء الاصطناعي للمحادثة
function addGeneratedImageToChat(imageUrl, prompt) {
    if (!currentChatId) {
        console.error('لا يوجد شات نشط');
        return;
    }
    
    // إنشاء رسالة للمستخدم توضح طلب توليد الصورة
    const userMessage = {
        id: Date.now(),
        content: `🎨 طلب توليد صورة: "${prompt}"`,
        sender: 'user',
        timestamp: new Date().toISOString()
    };
    
    addMessageToUI(userMessage.content, userMessage.sender, userMessage.timestamp);
    addMessageToChat(userMessage);
    
    // إضافة الصورة المولدة كرسالة من الذكاء الاصطناعي
    setTimeout(() => {
        const aiMessage = {
            id: Date.now() + 1,
            content: '✨ تم توليد الصورة بنجاح!',
            sender: 'ai',
            timestamp: new Date().toISOString(),
            images: [imageUrl]
        };
        
        addMessageToUI(aiMessage.content, aiMessage.sender, aiMessage.timestamp, aiMessage.images);
        addMessageToChat(aiMessage);
    }, 500);
}

// ====================================
// وظائف تلخيص المحادثة
// ====================================

let currentSummary = '';

// فتح نافذة التلخيص
document.getElementById('summarize-chat-btn')?.addEventListener('click', function() {
    if (!currentChatId) {
        showNotification('⚠️ يرجى اختيار محادثة أولاً', 'error');
        return;
    }
    
    const chat = chats.find(c => c.id === currentChatId);
    if (!chat || chat.messages.length === 0) {
        showNotification('⚠️ لا توجد رسائل لتلخيصها', 'error');
        return;
    }
    
    // إخفاء النتائج السابقة
    document.getElementById('summary-result').style.display = 'none';
    document.getElementById('summary-status').style.display = 'none';
    
    // فتح النافذة
    document.getElementById('summary-modal').style.display = 'flex';
});

// إنشاء الملخص
document.getElementById('generate-summary-btn')?.addEventListener('click', async function() {
    const chat = chats.find(c => c.id === currentChatId);
    if (!chat) return;
    
    const summaryType = document.getElementById('summary-type').value;
    const summaryLanguage = document.getElementById('summary-language').value;
    const includeTopics = document.getElementById('include-topics').checked;
    const includeDecisions = document.getElementById('include-decisions').checked;
    const includeQuestions = document.getElementById('include-questions').checked;
    const includeActionItems = document.getElementById('include-action-items').checked;
    
    // عرض حالة التحميل
    const statusDiv = document.getElementById('summary-status');
    statusDiv.style.display = 'block';
    statusDiv.innerHTML = '<div class="loading-message">🔄 جاري إنشاء الملخص...</div>';
    
    // إخفاء النتيجة السابقة
    document.getElementById('summary-result').style.display = 'none';
    
    // تعطيل الزر
    this.disabled = true;
    
    try {
        // بناء prompt للتلخيص
        const summary = await generateChatSummary(chat, {
            type: summaryType,
            language: summaryLanguage,
            includeTopics,
            includeDecisions,
            includeQuestions,
            includeActionItems
        });
        
        // عرض الملخص
        currentSummary = summary;
        document.getElementById('summary-content').innerHTML = formatSummary(summary);
        document.getElementById('summary-result').style.display = 'block';
        
        // إخفاء حالة التحميل
        statusDiv.innerHTML = '<div class="success-message">✅ تم إنشاء الملخص بنجاح!</div>';
        setTimeout(() => {
            statusDiv.style.display = 'none';
        }, 2000);
        
    } catch (error) {
        console.error('خطأ في التلخيص:', error);
        statusDiv.innerHTML = '<div class="error-message">❌ فشل في إنشاء الملخص. يرجى المحاولة مرة أخرى.</div>';
    } finally {
        this.disabled = false;
    }
});

// دالة توليد الملخص بالذكاء الاصطناعي
async function generateChatSummary(chat, options) {
    console.log('🤖 بدء توليد ملخص المحادثة...');
    
    // بناء نص المحادثة
    const conversationText = chat.messages.map((msg, index) => {
        return `[${index + 1}] ${msg.sender === 'user' ? 'المستخدم' : 'المساعد'}: ${msg.content}`;
    }).join('\n');
    
    // بناء prompt حسب الخيارات
    let prompt = `أنت خبير في تلخيص المحادثات. يرجى تلخيص المحادثة التالية:\n\n`;
    prompt += `=== بداية المحادثة ===\n${conversationText}\n=== نهاية المحادثة ===\n\n`;
    
    prompt += `نوع الملخص: `;
    if (options.type === 'brief') {
        prompt += 'قصير (نقاط رئيسية فقط - 3-5 نقاط)\n';
    } else if (options.type === 'medium') {
        prompt += 'متوسط (ملخص شامل - فقرة أو فقرتين)\n';
    } else {
        prompt += 'مفصل (تحليل كامل مع التفاصيل)\n';
    }
    
    prompt += '\nيرجى تضمين:\n';
    if (options.includeTopics) prompt += '- المواضيع والأفكار الرئيسية\n';
    if (options.includeDecisions) prompt += '- القرارات والنتائج المهمة\n';
    if (options.includeQuestions) prompt += '- الأسئلة الرئيسية المطروحة\n';
    if (options.includeActionItems) prompt += '- المهام والإجراءات المطلوبة\n';
    
    if (options.language === 'ar') {
        prompt += '\nيرجى كتابة الملخص بالعربية.';
    } else if (options.language === 'en') {
        prompt += '\nPlease write the summary in English.';
    } else {
        prompt += '\nيرجى كتابة الملخص بنفس لغة المحادثة.';
    }
    
    prompt += '\n\nنسق الملخص بطريقة واضحة ومنظمة مع استخدام العناوين والنقاط.';
    
    try {
        // استخدام Gemini API للتلخيص
        const response = await getGeminiResponse(prompt);
        console.log('✅ تم إنشاء الملخص بنجاح');
        return response;
    } catch (error) {
        console.error('❌ خطأ في Gemini API:', error);
        
        // ملخص افتراضي في حالة فشل API
        return generateFallbackSummary(chat, options);
    }
}

// ملخص احتياطي في حالة فشل API
function generateFallbackSummary(chat, options) {
    let summary = '📋 ملخص المحادثة\n\n';
    
    summary += `📊 معلومات عامة:\n`;
    summary += `- اسم المحادثة: ${chat.name}\n`;
    summary += `- عدد الرسائل: ${chat.messages.length}\n`;
    summary += `- تاريخ الإنشاء: ${new Date(chat.createdAt).toLocaleDateString('ar-EG')}\n\n`;
    
    if (options.includeTopics) {
        summary += `💡 الموضوع الرئيسي:\n`;
        summary += `${chat.description}\n\n`;
    }
    
    if (chat.messages.length > 0) {
        summary += `📝 أول رسالة:\n`;
        summary += `"${chat.messages[0].content.substring(0, 100)}..."\n\n`;
        
        if (chat.messages.length > 1) {
            summary += `💬 آخر رسالة:\n`;
            const lastMsg = chat.messages[chat.messages.length - 1];
            summary += `"${lastMsg.content.substring(0, 100)}..."\n`;
        }
    }
    
    return summary;
}

// تنسيق الملخص
function formatSummary(summary) {
    // تحويل النص إلى HTML منسق
    let formatted = summary;
    
    // تحويل العناوين
    formatted = formatted.replace(/^### (.+)$/gm, '<h4>$1</h4>');
    formatted = formatted.replace(/^## (.+)$/gm, '<h4>$1</h4>');
    formatted = formatted.replace(/^# (.+)$/gm, '<h4>$1</h4>');
    
    // تحويل النقاط
    formatted = formatted.replace(/^- (.+)$/gm, '<li>$1</li>');
    formatted = formatted.replace(/^• (.+)$/gm, '<li>$1</li>');
    formatted = formatted.replace(/^→ (.+)$/gm, '<li>$1</li>');
    
    // تحويل النص العريض
    formatted = formatted.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    
    // إضافة فواصل الأسطر
    formatted = formatted.replace(/\n\n/g, '<br><br>');
    formatted = formatted.replace(/\n/g, '<br>');
    
    // تغليف النقاط بقائمة
    if (formatted.includes('<li>')) {
        formatted = formatted.replace(/(<li>.*<\/li>)/s, '<ul>$1</ul>');
    }
    
    return formatted;
}

// نسخ الملخص
function copySummaryToClipboard() {
    const summaryText = currentSummary;
    
    navigator.clipboard.writeText(summaryText).then(() => {
        showNotification('📋 تم نسخ الملخص!', 'success');
    }).catch(err => {
        console.error('فشل النسخ:', err);
        showNotification('❌ فشل النسخ', 'error');
    });
}

// تحميل الملخص كملف
function downloadSummary() {
    const chat = chats.find(c => c.id === currentChatId);
    if (!chat) return;
    
    const filename = `ملخص_${chat.name}_${new Date().toLocaleDateString('ar-EG').replace(/\//g, '-')}.txt`;
    const text = currentSummary;
    
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    showNotification('💾 تم تحميل الملخص!', 'success');
}

// إضافة الملخص للمحادثة
function addSummaryToChat() {
    if (!currentChatId) return;
    
    const summaryMessage = {
        id: Date.now(),
        content: `📝 ملخص المحادثة:\n\n${currentSummary}`,
        sender: 'ai',
        timestamp: new Date().toISOString()
    };
    
    addMessageToUI(summaryMessage.content, summaryMessage.sender, summaryMessage.timestamp);
    addMessageToChat(summaryMessage);
    
    // إغلاق النافذة
    document.getElementById('summary-modal').style.display = 'none';
    
    showNotification('✅ تمت إضافة الملخص للمحادثة!', 'success');
}

// ====================
// وظائف البحث
// ====================

let searchResults = [];
let currentSearchIndex = -1;

// إظهار/إخفاء شريط البحث
document.getElementById('search-messages-btn')?.addEventListener('click', () => {
    const searchBar = document.getElementById('search-bar');
    const searchInput = document.getElementById('search-input');
    
    if (searchBar.style.display === 'none' || !searchBar.style.display) {
        searchBar.style.display = 'block';
        searchInput.focus();
    } else {
        searchBar.style.display = 'none';
        clearSearch();
    }
});

// إغلاق البحث
document.getElementById('close-search')?.addEventListener('click', () => {
    document.getElementById('search-bar').style.display = 'none';
    clearSearch();
});

// البحث في الرسائل
document.getElementById('search-input')?.addEventListener('input', (e) => {
    const query = e.target.value.trim();
    
    if (query.length === 0) {
        clearSearch();
        return;
    }
    
    performSearch(query);
});

// الفلاتر
document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        // إزالة active من الجميع
        document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        // إضافة active للزر الحالي
        this.classList.add('active');
        
        const filter = this.dataset.filter;
        applySearchFilter(filter);
    });
});

function performSearch(query) {
    const messages = document.querySelectorAll('.message');
    searchResults = [];
    
    messages.forEach((msg, index) => {
        const content = msg.dataset.content || msg.querySelector('.message-content')?.textContent || '';
        const sender = msg.dataset.sender;
        
        // إزالة التمييز السابق
        msg.classList.remove('search-highlight');
        const messageContent = msg.querySelector('.message-content');
        if (messageContent) {
            messageContent.innerHTML = content;
        }
        
        // البحث
        if (content.toLowerCase().includes(query.toLowerCase())) {
            searchResults.push({ element: msg, index, content, sender });
            msg.classList.add('search-highlight');
            
            // تمييز النص
            if (messageContent) {
                const regex = new RegExp(`(${query})`, 'gi');
                messageContent.innerHTML = content.replace(regex, '<span class="search-match">$1</span>');
            }
        }
    });
    
    // عرض النتائج
    const resultCount = document.getElementById('search-results-count');
    if (searchResults.length > 0) {
        resultCount.textContent = `تم العثور على ${searchResults.length} نتيجة`;
        // الانتقال لأول نتيجة
        searchResults[0].element.scrollIntoView({ behavior: 'smooth', block: 'center' });
    } else {
        resultCount.textContent = 'لم يتم العثور على نتائج';
    }
}

function applySearchFilter(filter) {
    const query = document.getElementById('search-input').value.trim();
    
    if (filter === 'all') {
        if (query) performSearch(query);
        return;
    }
    
    const messages = document.querySelectorAll('.message');
    messages.forEach(msg => {
        const sender = msg.dataset.sender;
        
        if (filter === 'user' && sender !== 'user') {
            msg.style.display = 'none';
        } else if (filter === 'ai' && sender !== 'ai') {
            msg.style.display = 'none';
        } else if (filter === 'date') {
            // يمكن إضافة منطق فلترة حسب التاريخ هنا
            msg.style.display = 'flex';
        } else {
            msg.style.display = 'flex';
        }
    });
}

function clearSearch() {
    const messages = document.querySelectorAll('.message');
    
    messages.forEach(msg => {
        msg.classList.remove('search-highlight');
        msg.style.display = 'flex';
        
        const messageContent = msg.querySelector('.message-content');
        const content = msg.dataset.content || messageContent?.textContent || '';
        if (messageContent) {
            messageContent.innerHTML = content;
        }
    });
    
    searchResults = [];
    document.getElementById('search-results-count').textContent = '';
    document.getElementById('search-input').value = '';
    
    // إعادة تعيين الفلترات
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    document.querySelector('.filter-btn[data-filter="all"]')?.classList.add('active');
}

// ====================
// وظائف المفضلة
// ====================

let favorites = JSON.parse(localStorage.getItem('favorites')) || {};

// إظهار نافذة المفضلة
document.getElementById('show-favorites-btn')?.addEventListener('click', () => {
    showFavoritesModal();
});

function showFavoritesModal() {
    const modal = document.getElementById('favorites-modal');
    modal.classList.add('show');
    renderFavorites();
}

function closeFavoritesModal() {
    const modal = document.getElementById('favorites-modal');
    modal.classList.remove('show');
}

// إضافة/إزالة من المفضلة
function toggleFavorite(button) {
    const messageDiv = button.closest('.message');
    const messageId = button.dataset.messageId;
    const content = messageDiv.dataset.content;
    const sender = messageDiv.dataset.sender;
    const timestamp = messageDiv.dataset.timestamp;
    
    if (button.classList.contains('favorited')) {
        // إزالة من المفضلة
        delete favorites[messageId];
        button.classList.remove('favorited');
        showNotification('تمت إزالة الرسالة من المفضلة', 'info');
    } else {
        // إضافة للمفضلة
        favorites[messageId] = {
            id: messageId,
            chatId: currentChatId,
            content,
            sender,
            timestamp,
            addedAt: new Date().toISOString()
        };
        button.classList.add('favorited');
        showNotification('✨ تمت إضافة الرسالة للمفضلة', 'success');
    }
    
    saveFavorites();
}

function isMessageFavorited(messageId) {
    return !!favorites[messageId];
}

function saveFavorites() {
    localStorage.setItem('favorites', JSON.stringify(favorites));
}

function renderFavorites() {
    const favoritesList = document.getElementById('favorites-list');
    const noFavorites = document.getElementById('no-favorites');
    
    const favoriteItems = Object.values(favorites);
    
    if (favoriteItems.length === 0) {
        favoritesList.innerHTML = '';
        noFavorites.style.display = 'block';
        return;
    }
    
    noFavorites.style.display = 'none';
    
    favoritesList.innerHTML = favoriteItems.map(fav => {
        const senderName = fav.sender === 'user' ? '👤 أنت' : '🤖 المساعد الذكي';
        const date = new Date(fav.timestamp).toLocaleString('ar-SA', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
        
        return `
            <div class="favorite-item" data-favorite-id="${fav.id}">
                <div class="favorite-item-header">
                    <span class="favorite-sender">${senderName}</span>
                    <span class="favorite-date">${date}</span>
                </div>
                <div class="favorite-content">${fav.content}</div>
                <div class="favorite-actions">
                    <button class="favorite-action-btn" onclick="copyFavoriteText('${fav.id}')">
                        📋 نسخ
                    </button>
                    <button class="favorite-action-btn remove" onclick="removeFavorite('${fav.id}')">
                        🗑️ حذف
                    </button>
                </div>
            </div>
        `;
    }).join('');
}

function removeFavorite(favoriteId) {
    if (confirm('هل تريد إزالة هذه الرسالة من المفضلة؟')) {
        delete favorites[favoriteId];
        saveFavorites();
        renderFavorites();
        
        // تحديث الزر في الرسالة إذا كانت مفتوحة
        const button = document.querySelector(`[data-message-id="${favoriteId}"]`);
        if (button) {
            button.classList.remove('favorited');
        }
        
        showNotification('تمت إزالة الرسالة من المفضلة', 'info');
    }
}

function copyFavoriteText(favoriteId) {
    const favorite = favorites[favoriteId];
    if (!favorite) return;
    
    navigator.clipboard.writeText(favorite.content).then(() => {
        showNotification('✅ تم نسخ النص', 'success');
    }).catch(err => {
        console.error('خطأ في النسخ:', err);
        showNotification('❌ فشل النسخ', 'error');
    });
}

// إشعارات
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    // تحديد اللون حسب النوع
    const colors = {
        success: '#4CAF50',
        error: '#f44336',
        info: '#2196F3',
        warning: '#ff9800'
    };
    
    notification.style.background = colors[type] || colors.info;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOutNotification 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// ======== الاقتراحات الذكية ========

function handleInputForSuggestions() {
    const text = messageInput.value.trim();
    
    // إلغاء الـ timeout السابق
    if (suggestionsTimeout) {
        clearTimeout(suggestionsTimeout);
    }
    
    // إذا كان النص أقل من 3 أحرف، اخفي الاقتراحات
    if (text.length < 3) {
        hideSuggestions();
        return;
    }
    
    // انتظر 500ms قبل طلب الاقتراحات
    suggestionsTimeout = setTimeout(() => {
        generateSuggestions(text);
    }, 500);
}

function generateSuggestions(text) {
    // اقتراحات ذكية بناءً على النص
    const suggestions = [
        {
            text: `${text}؟`,
            type: 'سؤال',
            icon: '❓'
        },
        {
            text: `ممكن توضحلي أكتر عن ${text}؟`,
            type: 'استفسار',
            icon: '🤔'
        },
        {
            text: `أريد معرفة المزيد عن ${text}`,
            type: 'طلب',
            icon: '📚'
        },
        {
            text: `اشرحلي ${text} بطريقة مبسطة`,
            type: 'شرح',
            icon: '💡'
        },
        {
            text: `أمثلة على ${text}`,
            type: 'أمثلة',
            icon: '📝'
        }
    ];
    
    // فلترة الاقتراحات بناءً على السياق
    const filteredSuggestions = suggestions.filter(s => 
        !text.includes('؟') && !text.includes('؟')
    );
    
    currentSuggestions = filteredSuggestions.slice(0, 4);
    showSuggestions(currentSuggestions);
}

function showSuggestions(suggestions) {
    if (!suggestionsContainer || !suggestionsList) return;
    
    // تفريغ القائمة
    suggestionsList.innerHTML = '';
    
    // إضافة الاقتراحات
    suggestions.forEach((suggestion, index) => {
        const item = document.createElement('div');
        item.className = 'suggestion-item';
        item.innerHTML = `
            <span class="suggestion-icon">${suggestion.icon}</span>
            <span class="suggestion-text">${suggestion.text}</span>
            <span class="suggestion-type">${suggestion.type}</span>
        `;
        
        item.addEventListener('click', () => {
            selectSuggestion(suggestion.text);
        });
        
        suggestionsList.appendChild(item);
    });
    
    // عرض النافذة
    suggestionsContainer.style.display = 'block';
}

function hideSuggestions() {
    if (suggestionsContainer) {
        suggestionsContainer.style.display = 'none';
    }
    currentSuggestions = [];
}

function selectSuggestion(text) {
    messageInput.value = text;
    hideSuggestions();
    messageInput.focus();
    
    // تعديل حجم textarea
    autoResizeTextarea();
}

// ======== التسجيل الصوتي ========

async function toggleVoiceRecording() {
    if (isRecording) {
        stopVoiceRecording();
    } else {
        await startVoiceRecording();
    }
}

async function startVoiceRecording() {
    try {
        // التحقق من دعم Web Speech API
        if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
            showNotification('❌ المتصفح لا يدعم التسجيل الصوتي', 'error');
            return;
        }
        
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        const recognition = new SpeechRecognition();
        
        // إعدادات التسجيل
        recognition.lang = 'ar-SA'; // اللغة العربية
        recognition.continuous = false;
        recognition.interimResults = true;
        recognition.maxAlternatives = 1;
        
        // عند بدء التسجيل
        recognition.onstart = () => {
            isRecording = true;
            voiceButton.classList.add('recording');
            voiceRecordingIndicator.style.display = 'flex';
            startRecordingTimer();
            showNotification('🎙️ جاري التسجيل الصوتي...', 'info');
        };
        
        // عند الحصول على نتائج
        recognition.onresult = (event) => {
            const current = event.resultIndex;
            const transcript = event.results[current][0].transcript;
            
            if (event.results[current].isFinal) {
                // إضافة النص النهائي إلى حقل الإدخال
                messageInput.value += transcript;
                autoResizeTextarea();
                hideSuggestions();
            }
        };
        
        // عند انتهاء التسجيل
        recognition.onend = () => {
            stopVoiceRecording();
        };
        
        // عند حدوث خطأ
        recognition.onerror = (event) => {
            console.error('خطأ في التسجيل الصوتي:', event.error);
            let errorMessage = '❌ حدث خطأ في التسجيل الصوتي';
            
            switch(event.error) {
                case 'no-speech':
                    errorMessage = '❌ لم يتم الكشف عن أي كلام';
                    break;
                case 'audio-capture':
                    errorMessage = '❌ لا يمكن الوصول للميكروفون';
                    break;
                case 'not-allowed':
                    errorMessage = '❌ تم رفض الإذن للوصول للميكروفون';
                    break;
                case 'network':
                    errorMessage = '❌ خطأ في الشبكة';
                    break;
            }
            
            showNotification(errorMessage, 'error');
            stopVoiceRecording();
        };
        
        // بدء التسجيل
        recognition.start();
        mediaRecorder = recognition;
        
    } catch (error) {
        console.error('خطأ في بدء التسجيل:', error);
        showNotification('❌ لا يمكن بدء التسجيل الصوتي', 'error');
    }
}

function stopVoiceRecording() {
    if (mediaRecorder && typeof mediaRecorder.stop === 'function') {
        mediaRecorder.stop();
    }
    
    isRecording = false;
    voiceButton.classList.remove('recording');
    voiceRecordingIndicator.style.display = 'none';
    stopRecordingTimer();
    
    showNotification('✅ تم إنهاء التسجيل الصوتي', 'success');
}

function startRecordingTimer() {
    recordingStartTime = Date.now();
    updateRecordingTime();
    
    recordingTimer = setInterval(() => {
        updateRecordingTime();
    }, 1000);
}

function stopRecordingTimer() {
    if (recordingTimer) {
        clearInterval(recordingTimer);
        recordingTimer = null;
    }
    recordingStartTime = null;
}

function updateRecordingTime() {
    if (!recordingStartTime) return;
    
    const elapsed = Math.floor((Date.now() - recordingStartTime) / 1000);
    const minutes = Math.floor(elapsed / 60);
    const seconds = elapsed % 60;
    
    const timeString = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    recordingTimeDisplay.textContent = timeString;
}

// ======== القراءة الصوتية ========

function toggleVoiceOutput() {
    voiceOutputEnabled = !voiceOutputEnabled;
    const voiceBtn = document.getElementById('toggle-voice-btn');
    
    if (voiceOutputEnabled) {
        voiceBtn.classList.add('active');
        showNotification('🔊 تم تفعيل القراءة الصوتية', 'success');
    } else {
        voiceBtn.classList.remove('active');
        stopCurrentSpeech();
        showNotification('🔇 تم إيقاف القراءة الصوتية', 'info');
    }
}

function speakText(text) {
    if (!voiceOutputEnabled || !text) return;
    
    // إيقاف أي قراءة حالية
    stopCurrentSpeech();
    
    try {
        currentUtterance = new SpeechSynthesisUtterance(text);
        
        // إعدادات الصوت العربي
        currentUtterance.lang = 'ar-SA';
        currentUtterance.rate = 0.9; // سرعة متوسطة
        currentUtterance.pitch = 1.0; // طبقة صوت طبيعية
        currentUtterance.volume = 1.0; // أقصى مستوى صوت
        
        // البحث عن صوت عربي
        const voices = speechSynthesis.getVoices();
        const arabicVoice = voices.find(voice => 
            voice.lang.includes('ar') || voice.name.includes('Arabic')
        );
        
        if (arabicVoice) {
            currentUtterance.voice = arabicVoice;
        }
        
        // أحداث القراءة
        currentUtterance.onstart = () => {
            console.log('بدء القراءة الصوتية');
        };
        
        currentUtterance.onend = () => {
            currentUtterance = null;
        };
        
        currentUtterance.onerror = (event) => {
            console.error('خطأ في القراءة الصوتية:', event.error);
            currentUtterance = null;
        };
        
        // بدء القراءة
        speechSynthesis.speak(currentUtterance);
        
    } catch (error) {
        console.error('خطأ في تهيئة القراءة الصوتية:', error);
        showNotification('❌ لا يمكن تشغيل القراءة الصوتية', 'error');
    }
}

function stopCurrentSpeech() {
    if (speechSynthesis.speaking) {
        speechSynthesis.cancel();
    }
    currentUtterance = null;
}

// تعديل دالة عرض الرسائل لإضافة زر القراءة الصوتية
function addVoiceButtonToMessage(messageElement, text) {
    if (!messageElement || !text) return;
    
    // التحقق إذا كانت الرسالة من AI
    if (!messageElement.classList.contains('ai-message')) return;
    
    // إنشاء زر القراءة الصوتية
    const voiceBtn = document.createElement('button');
    voiceBtn.className = 'message-voice-btn';
    voiceBtn.innerHTML = '🔊';
    voiceBtn.title = 'اقرأ هذه الرسالة';
    
    voiceBtn.addEventListener('click', () => {
        speakText(text);
    });
    
    // إضافة الزر إلى الرسالة
    const messageActions = messageElement.querySelector('.message-actions') || 
                         messageElement.querySelector('.message-content');
    
    if (messageActions) {
        messageActions.appendChild(voiceBtn);
    }
}

// إضافة أنماط الأنيميشن
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);
