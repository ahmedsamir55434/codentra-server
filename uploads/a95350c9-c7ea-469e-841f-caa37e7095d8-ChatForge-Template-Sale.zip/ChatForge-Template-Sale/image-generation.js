// ChatForge - Image Generation Module
// توليد الصور بالذكاء الاصطناعي

console.log('🎨 تم تحميل وحدة توليد الصور');

// إعدادات توليد الصور
const IMAGE_GEN_CONFIG = {
    // Pollinations.ai - مجاني بدون API key
    POLLINATIONS_URL: 'https://image.pollinations.ai/prompt/',
    
    // Stability AI - يحتاج API key
    STABILITY_API_KEY: localStorage.getItem('stability_api_key') || '',
    STABILITY_URL: 'https://api.stability.ai/v1/generation/stable-diffusion-xl-1024-v1-0/text-to-image',
    
    // الإعدادات الافتراضية
    DEFAULT_WIDTH: 1024,
    DEFAULT_HEIGHT: 1024,
    DEFAULT_STYLE: 'realistic',
    
    // أنماط الصور المتاحة
    STYLES: {
        realistic: 'واقعي',
        artistic: 'فني',
        anime: 'أنمي',
        digital_art: 'فن رقمي',
        oil_painting: 'لوحة زيتية',
        watercolor: 'ألوان مائية',
        sketch: 'رسم تخطيطي',
        cyberpunk: 'سايبربانك',
        fantasy: 'خيالي'
    }
};

// دالة رئيسية لتوليد الصور
async function generateImage(prompt, options = {}) {
    const {
        width = IMAGE_GEN_CONFIG.DEFAULT_WIDTH,
        height = IMAGE_GEN_CONFIG.DEFAULT_HEIGHT,
        style = IMAGE_GEN_CONFIG.DEFAULT_STYLE,
        provider = 'pollinations' // 'pollinations' أو 'stability'
    } = options;
    
    console.log('🎨 بدء توليد الصورة...');
    console.log('📝 الوصف:', prompt);
    console.log('🎭 النمط:', style);
    console.log('📐 الحجم:', `${width}x${height}`);
    console.log('🔧 المزود:', provider);
    
    try {
        if (provider === 'pollinations') {
            return await generateImagePollinations(prompt, width, height, style);
        } else if (provider === 'stability') {
            return await generateImageStability(prompt, width, height, style);
        } else {
            throw new Error('مزود غير معروف');
        }
    } catch (error) {
        console.error('❌ خطأ في توليد الصورة:', error);
        throw error;
    }
}

// توليد صورة باستخدام Pollinations.ai (مجاني)
async function generateImagePollinations(prompt, width, height, style) {
    console.log('🌸 استخدام Pollinations.ai...');
    
    // تحسين الـ prompt حسب النمط
    const enhancedPrompt = enhancePromptWithStyle(prompt, style);
    
    // ترميز الـ prompt
    const encodedPrompt = encodeURIComponent(enhancedPrompt);
    
    // بناء URL
    const imageUrl = `${IMAGE_GEN_CONFIG.POLLINATIONS_URL}${encodedPrompt}?width=${width}&height=${height}&seed=${Date.now()}&nologo=true`;
    
    console.log('🔗 URL الصورة:', imageUrl);
    
    // التحقق من أن الصورة متاحة
    try {
        const response = await fetch(imageUrl);
        if (!response.ok) {
            throw new Error('فشل في توليد الصورة');
        }
        
        console.log('✅ تم توليد الصورة بنجاح');
        
        return {
            success: true,
            imageUrl: imageUrl,
            prompt: prompt,
            enhancedPrompt: enhancedPrompt,
            provider: 'pollinations',
            timestamp: new Date().toISOString()
        };
    } catch (error) {
        console.error('❌ خطأ في Pollinations:', error);
        throw new Error('فشل في توليد الصورة. يرجى المحاولة مرة أخرى.');
    }
}

// توليد صورة باستخدام Stability AI (يحتاج API key)
async function generateImageStability(prompt, width, height, style) {
    console.log('🏔️ استخدام Stability AI...');
    
    if (!IMAGE_GEN_CONFIG.STABILITY_API_KEY) {
        throw new Error('❌ لا يوجد مفتاح Stability AI. يرجى إضافة المفتاح في الإعدادات.');
    }
    
    const enhancedPrompt = enhancePromptWithStyle(prompt, style);
    
    const requestBody = {
        text_prompts: [
            {
                text: enhancedPrompt,
                weight: 1
            }
        ],
        cfg_scale: 7,
        height: height,
        width: width,
        samples: 1,
        steps: 30
    };
    
    try {
        const response = await fetch(IMAGE_GEN_CONFIG.STABILITY_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${IMAGE_GEN_CONFIG.STABILITY_API_KEY}`,
                'Accept': 'application/json'
            },
            body: JSON.stringify(requestBody)
        });
        
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.message || 'فشل في توليد الصورة');
        }
        
        const data = await response.json();
        
        if (!data.artifacts || data.artifacts.length === 0) {
            throw new Error('لم يتم إنتاج صورة');
        }
        
        const base64Image = data.artifacts[0].base64;
        const imageUrl = `data:image/png;base64,${base64Image}`;
        
        console.log('✅ تم توليد الصورة بنجاح باستخدام Stability AI');
        
        return {
            success: true,
            imageUrl: imageUrl,
            prompt: prompt,
            enhancedPrompt: enhancedPrompt,
            provider: 'stability',
            timestamp: new Date().toISOString()
        };
    } catch (error) {
        console.error('❌ خطأ في Stability AI:', error);
        throw error;
    }
}

// تحسين الـ prompt حسب النمط المختار
function enhancePromptWithStyle(prompt, style) {
    const styleEnhancements = {
        realistic: 'photorealistic, high quality, detailed, 8k',
        artistic: 'artistic, creative, expressive, beautiful colors',
        anime: 'anime style, manga, japanese animation, vibrant',
        digital_art: 'digital art, modern, clean, professional',
        oil_painting: 'oil painting style, classical art, textured',
        watercolor: 'watercolor painting, soft colors, artistic',
        sketch: 'pencil sketch, hand-drawn, artistic lines',
        cyberpunk: 'cyberpunk style, neon lights, futuristic, sci-fi',
        fantasy: 'fantasy art, magical, epic, detailed'
    };
    
    const enhancement = styleEnhancements[style] || '';
    return enhancement ? `${prompt}, ${enhancement}` : prompt;
}

// حفظ مفتاح Stability AI
function setStabilityAPIKey(apiKey) {
    IMAGE_GEN_CONFIG.STABILITY_API_KEY = apiKey;
    localStorage.setItem('stability_api_key', apiKey);
    console.log('✅ تم حفظ مفتاح Stability AI');
}

// تحميل مفتاح Stability AI
function loadStabilityAPIKey() {
    const savedKey = localStorage.getItem('stability_api_key');
    if (savedKey) {
        IMAGE_GEN_CONFIG.STABILITY_API_KEY = savedKey;
        console.log('🔑 تم تحميل مفتاح Stability AI من التخزين المحلي');
    }
}

// إظهار نافذة توليد الصور
function showImageGenerationModal() {
    const modal = document.createElement('div');
    modal.className = 'modal show';
    modal.id = 'image-gen-modal';
    modal.innerHTML = `
        <div class="modal-content image-gen-modal">
            <div class="modal-header">
                <h2>🎨 توليد صورة بالذكاء الاصطناعي</h2>
                <button class="close-button" onclick="closeImageGenModal()">×</button>
            </div>
            <div class="modal-body">
                <div class="input-group">
                    <label for="image-prompt-input">وصف الصورة المطلوبة</label>
                    <textarea 
                        id="image-prompt-input" 
                        placeholder="مثال: قطة بيضاء تجلس على سطح منزل في ليلة مقمرة، الأسلوب الفني واقعي"
                        rows="3"
                    ></textarea>
                    <small>اكتب وصفاً دقيقاً للصورة التي تريد توليدها</small>
                </div>
                
                <div class="input-group">
                    <label for="image-style-select">نمط الصورة</label>
                    <select id="image-style-select">
                        <option value="realistic">واقعي</option>
                        <option value="artistic">فني</option>
                        <option value="anime">أنمي</option>
                        <option value="digital_art">فن رقمي</option>
                        <option value="oil_painting">لوحة زيتية</option>
                        <option value="watercolor">ألوان مائية</option>
                        <option value="sketch">رسم تخطيطي</option>
                        <option value="cyberpunk">سايبربانك</option>
                        <option value="fantasy">خيالي</option>
                    </select>
                </div>
                
                <div class="input-group">
                    <label for="image-size-select">حجم الصورة</label>
                    <select id="image-size-select">
                        <option value="512">512x512 (صغير - سريع)</option>
                        <option value="768">768x768 (متوسط)</option>
                        <option value="1024" selected>1024x1024 (كبير - عالي الجودة)</option>
                    </select>
                </div>
                
                <div class="input-group">
                    <label for="image-provider-select">مزود الخدمة</label>
                    <select id="image-provider-select">
                        <option value="pollinations" selected>Pollinations.ai (مجاني - موصى به)</option>
                        <option value="stability">Stability AI (يحتاج API key)</option>
                    </select>
                    <small id="provider-note">خدمة مجانية بدون الحاجة لمفتاح API</small>
                </div>
                
                <div id="stability-key-section" class="input-group hidden">
                    <label for="stability-key-input">مفتاح Stability AI</label>
                    <input 
                        type="password" 
                        id="stability-key-input" 
                        placeholder="أدخل مفتاح API من Stability AI"
                        value="${IMAGE_GEN_CONFIG.STABILITY_API_KEY}"
                    />
                    <small>احصل على المفتاح من <a href="https://platform.stability.ai/" target="_blank">Stability AI</a></small>
                </div>
                
                <div id="image-gen-status" class="generation-status"></div>
                
                <div id="generated-image-preview" class="generated-image-preview hidden">
                    <img id="generated-image" src="" alt="صورة مولدة" />
                    <div class="image-actions">
                        <button onclick="downloadGeneratedImage()" class="action-btn">
                            📥 تحميل
                        </button>
                        <button onclick="insertGeneratedImage()" class="action-btn primary">
                            ➕ إضافة للمحادثة
                        </button>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="secondary-button" onclick="closeImageGenModal()">إغلاق</button>
                <button class="primary-button" onclick="startImageGeneration()">
                    <span id="generate-btn-text">🎨 توليد الصورة</span>
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // إعداد المستمعين
    const providerSelect = document.getElementById('image-provider-select');
    const stabilityKeySection = document.getElementById('stability-key-section');
    const providerNote = document.getElementById('provider-note');
    
    providerSelect.addEventListener('change', function() {
        if (this.value === 'stability') {
            stabilityKeySection.classList.remove('hidden');
            providerNote.textContent = 'يحتاج مفتاح API من Stability AI (خدمة مدفوعة)';
            providerNote.style.color = '#ffa500';
        } else {
            stabilityKeySection.classList.add('hidden');
            providerNote.textContent = 'خدمة مجانية بدون الحاجة لمفتاح API';
            providerNote.style.color = '#00d4ff';
        }
    });
}

// إغلاق نافذة توليد الصور
function closeImageGenModal() {
    const modal = document.getElementById('image-gen-modal');
    if (modal) {
        modal.remove();
    }
}

// بدء توليد الصورة
async function startImageGeneration() {
    const promptInput = document.getElementById('image-prompt-input');
    const styleSelect = document.getElementById('image-style-select');
    const sizeSelect = document.getElementById('image-size-select');
    const providerSelect = document.getElementById('image-provider-select');
    const statusDiv = document.getElementById('image-gen-status');
    const generateBtn = document.getElementById('generate-btn-text');
    const stabilityKeyInput = document.getElementById('stability-key-input');
    
    const prompt = promptInput.value.trim();
    
    if (!prompt) {
        statusDiv.innerHTML = '<div class="error-message">❌ يرجى إدخال وصف للصورة</div>';
        return;
    }
    
    const style = styleSelect.value;
    const size = parseInt(sizeSelect.value);
    const provider = providerSelect.value;
    
    // حفظ مفتاح Stability إذا تم إدخاله
    if (provider === 'stability' && stabilityKeyInput.value.trim()) {
        setStabilityAPIKey(stabilityKeyInput.value.trim());
    }
    
    // تعطيل الزر وإظهار التحميل
    generateBtn.innerHTML = '⏳ جاري التوليد...';
    document.querySelector('.modal-footer .primary-button').disabled = true;
    statusDiv.innerHTML = '<div class="loading-message">🎨 جاري توليد الصورة... قد يستغرق هذا بضع ثوانٍ</div>';
    
    try {
        const result = await generateImage(prompt, {
            width: size,
            height: size,
            style: style,
            provider: provider
        });
        
        if (result.success) {
            // إظهار الصورة المولدة
            displayGeneratedImage(result);
            statusDiv.innerHTML = '<div class="success-message">✅ تم توليد الصورة بنجاح!</div>';
        } else {
            throw new Error('فشل في توليد الصورة');
        }
    } catch (error) {
        statusDiv.innerHTML = `<div class="error-message">❌ ${error.message}</div>`;
        console.error('خطأ في توليد الصورة:', error);
    } finally {
        generateBtn.innerHTML = '🎨 توليد الصورة';
        document.querySelector('.modal-footer .primary-button').disabled = false;
    }
}

// عرض الصورة المولدة
function displayGeneratedImage(result) {
    const preview = document.getElementById('generated-image-preview');
    const img = document.getElementById('generated-image');
    
    img.src = result.imageUrl;
    preview.classList.remove('hidden');
    
    // حفظ البيانات للاستخدام لاحقاً
    window.lastGeneratedImage = result;
}

// تحميل الصورة المولدة
function downloadGeneratedImage() {
    if (!window.lastGeneratedImage) return;
    
    const link = document.createElement('a');
    link.href = window.lastGeneratedImage.imageUrl;
    link.download = `chatforge-generated-${Date.now()}.png`;
    link.click();
}

// إضافة الصورة المولدة للمحادثة
function insertGeneratedImage() {
    if (!window.lastGeneratedImage) return;
    
    const imageUrl = window.lastGeneratedImage.imageUrl;
    const prompt = window.lastGeneratedImage.prompt;
    
    // إضافة الصورة كرسالة في المحادثة
    if (typeof addGeneratedImageToChat === 'function') {
        addGeneratedImageToChat(imageUrl, prompt);
    }
    
    closeImageGenModal();
}

// اختبار الاتصال بـ API
async function testImageGeneration() {
    console.log('🧪 اختبار توليد الصور...');
    
    try {
        const result = await generateImage('A beautiful sunset over the ocean', {
            width: 512,
            height: 512,
            style: 'realistic',
            provider: 'pollinations'
        });
        
        console.log('✅ اختبار نجح:', result);
        return { success: true, message: 'نجح الاختبار', result };
    } catch (error) {
        console.error('❌ فشل الاختبار:', error);
        return { success: false, message: error.message };
    }
}

// تحميل الإعدادات عند بدء التطبيق
document.addEventListener('DOMContentLoaded', function() {
    loadStabilityAPIKey();
    console.log('✅ تم تحميل وحدة توليد الصور بنجاح');
});

// تصدير الدوال للاستخدام في الملفات الأخرى
window.ImageGeneration = {
    generateImage,
    showImageGenerationModal,
    closeImageGenModal,
    setStabilityAPIKey,
    testImageGeneration
};
